// ==UserScript==
// @name        迷题暴击有开关
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  try to take over the world!
// @author       You
// @match        http://*.yytou.cn/*
// @exclude      http://res.yytou.cn/*
// @grant        none
// ==/UserScript==
var btnList = {};		// 按钮列表
var buttonWidth = '110px';	// 按钮宽度
var buttonHeight = '20px';	// 按钮高度
var currentPos = 400;		// 当前按钮距离顶端高度，初始130
var delta = 25;	                // 每个按钮间隔
//var corpseNPCLists = prompt("请输入要摸的目标","月老的尸体");

youxia_id = null;	// 游侠ID初始化
steps = 0;//路径记数清零
var imultiplePuzzle = 0;

var ipositiveKill=0;//刷正气  0：停止； 1：开始刷正气  杀段老大，二娘
var inegativeKill=0;//刷邪气  0：停止； 1：开始刷正气   查血量


mySkillLists = "逍遥剑;逍遥掌;茅山道术;扑击格斗之技;打狗棒法;莲花掌;散花掌;排云掌法;九天龙吟剑法;如来神掌;无相金刚掌;六脉神剑;无影毒阵;天师灭神剑;辟邪剑法;天师剑";
qxNpcList = "浪唤雨;王蓉;庞统;李宇飞;步惊鸿;风行骓;郭济;吴缜;风南;火云邪神;逆风舞;狐苍雁;护竺";
var forceList = "天邪神功;生生造化功;道种心魔经;混元一气功;易筋经神功";
var qlEquipList ="斩龙宝靴;龙皮至尊衣;斩龙宝戒;斩龙帽;斩龙宝链;斩龙宝镯;飞宇天怒刀;九天龙吟剑;小李飞刀;天罡掌套;乌金玄火鞭;开天宝棍;达摩杖";
var isDelayCmd = 1, // 是否延迟命令
    cmdCache = [],      // 命令池
    timeCmd = null,     // 定时器句柄
    cmdDelayTime = 200; // 命令延迟时间

// 执行命令串
function go(str) {
    var arr = str.split(";");
    if (isDelayCmd && cmdDelayTime) {
        // 把命令存入命令池中
        cmdCache = cmdCache.concat(arr);

        // 当前如果命令没在执行则开始执行
        if (!timeCmd) delayCmd();
    } else {
        for (var i = 0; i < arr.length; i++) clickButton(arr[i]);
    }
}

// 执行命令池中的命令
function delayCmd() {
    // 执行命令池中第一个命令，并从池中删除
    var cmd=cmdCache.shift();
    var arr=cmd.split(",");
    if(!sock) {
        return;
    }
    clickButton(arr[0]);
    for(var i=arr.length-1;i>0;i--){
        cmdCache.unshift(arr[i]);
    }

    // 如果命令池还有命令，则延时继续执行
    if (cmdCache.length > 0) {
        timeCmd = setTimeout(delayCmd, cmdDelayTime);
    } else {
        // 没有命令 则归零
        timeCmd = 1;
        setTimeout(function(){
            if(cmdCache.length === 0)
                timeCmd=0;
            else
                delayCmd();
        },cmdDelayTime);
    }

}
// 停止执行
function stopDelayCmd() {
    // 清除计时器
    clearTimeout(timeCmd);

    // 归零计时器
    timeCmd = 0;

    // 清除命令池
    cmdCache = [];
}


function sleep(d){
    for(var t = Date.now();Date.now() - t <= d;);
}

function isContains(str, substr) {
    return str.indexOf(substr) >= 0;
}
var myname = "我是谁";
var myMaxKee=0;
function WhoAmIFunc() {
    go('home_prompt');    // 主页
    go('score');    // 状态
    console.log("whoami1");
    var elem = $('span.out3:contains(】)').first();
    var m = elem.text().match(/】(.*)/);


    //  go('score');    // 状态
    var qixue = $('span.out3:contains(【气血】)').text();
    var neili = $('span.out3:contains(【内力】)').text();
    console.log(qixue);
    var qixueNum = qixue.match(/\d{1,}/g);// 气血
    var neiliNum = neili.match(/\d{1,}/g);// 内力
    var isMax = qixueNum[1] - qixueNum[0];
    myMaxKee=qixueNum[1] ;

    if (m != null) {
        myname = m[1];
        btnList["我是谁"].innerText =  myname;
    }
    go("prev");
}

function WhoAmI1Func() {
    console.log("whoami1");
    var elem = $('span.out3:contains(】)').first();
    var m = elem.text().match(/】(.*)/);
    //  go('score');    // 状态
    var qixue = $('span.out3:contains(【气血】)').text();
    var neili = $('span.out3:contains(【内力】)').text();
    console.log(qixue);
    var qixueNum = qixue.match(/\d{1,}/g);// 气血
    var neiliNum = neili.match(/\d{1,}/g);// 内力
    var isMax = qixueNum[1] - qixueNum[0];
    myMaxKee=qixueNum[1] ;

    if (m != null) {
        myname = m[1];
        btnList["我是谁"].innerText =  myname;
    }
    go("prev");
}
createButton('关菜单',guancaidan);
//createButton('回主页',GoHomeFunc);
//createButton('我是谁',WhoAmIFunc);
createButton('自动战斗',AutoKillFunc);
//createButton('摸尸体',AutoGetFunc);
//createButton('战斗装',ZhuangBei);
//createButton('扩背包',kbb);
createButton('包裹整理',clearBag);
//createButton('买千年',buyMedecineFunc);
createButton('疗伤10',LiaoShangFunc);
//createButton('吃千年',userMedecineFunc);
createButton('清谜题',clearPuzzleFunc);
createButton('单谜题',NpcBatchAskFunc);
createButton('自动迷题',listenPuzzleFunc);
createButton('进度',PuzzleNextFunc);
createButton('进度设置',PuzzleNPCGoFunc);
createButton('迷题扫图',GetNPCStart);
createButton('选择地图',buttonhide3Func);
function guancaidan(){
    if(btnList["关菜单"].innerText  == '关菜单'){
       // btnList["回主页"].style.display = "none";
        //btnList["我是谁"].style.display = "none";
        btnList["自动战斗"].style.display = "none";
       // btnList["扩背包"].style.display = "none";
        btnList["包裹整理"].style.display = "none";
       // btnList["买千年"].style.display = "none";
        btnList["疗伤10"].style.display = "none";
       // btnList["吃千年"].style.display = "none";
        btnList["清谜题"].style.display = "none";
        btnList["单谜题"].style.display = "none";
        btnList["自动迷题"].style.display = "none";
        btnList["进度"].style.display = "none";
        btnList["进度设置"].style.display = "none";
        btnList["迷题扫图"].style.display = "none";
        btnList["选择地图"].style.display = "none";
        btnList["关菜单"].innerText  = '开菜单';}
    else{
      //btnList["回主页"].style.display = "block";
        //btnList["我是谁"].style.display = "block";
        btnList["自动战斗"].style.display = "block";
      //  btnList["扩背包"].style.display = "block";
        btnList["包裹整理"].style.display = "block";
      //  btnList["买千年"].style.display = "block";
        btnList["疗伤10"].style.display = "block";
       // btnList["吃千年"].style.display = "block";
        btnList["清谜题"].style.display = "block";
        btnList["单谜题"].style.display = "block";
        btnList["自动迷题"].style.display = "block";
        btnList["进度"].style.display = "block";
        btnList["进度设置"].style.display = "block";
        btnList["迷题扫图"].style.display = "block";
        btnList["选择地图"].style.display = "block";
        {btnList["关菜单"].innerText  = '关菜单';}
    }
}

btnList['选择地图'].style.color='#FF0000';btnList['选择地图'].style.ground='#000000';
var Puzzletrigger=0;
function listenPuzzleFunc(){
    if (Puzzletrigger==0){
        Puzzletrigger=1;
        btnList["自动迷题"].innerText = '手动迷题';
    }else if (Puzzletrigger==1){
        Puzzletrigger=0;
        clearInterval(PuzzleActIntervalFunc);
        btnList["自动迷题"].innerText = '自动迷题';
    }
}



// 雪亭镇  洛阳 华山村 华山 扬州 丐帮 乔阴县 峨眉山 恒山 武当山 晚月庄 水烟阁 少林寺 唐门 青城山 逍遥林 开封 光明顶 全真教 古墓 白驮山

function testMapPath() {
    var w='雪亭镇';
    if (w.startsWith("雪亭镇")) {
        go_path = "jh 1;e;s;w;w;e;s;n;e;e;ne;ne;sw;sw;n;w;n;e;e;n;s;e;e;n;s;e;w;s;n;w;w;w;w;w;e;n;w;e;n;w;e;e;e;w;w;n;n;s;e;w;w";
    } else if (w.startsWith("洛阳")) {
        go_path = "jh 2;n;n;e;s;n;w;n;e;s;n;w;w;e;n;w;s;w;e;n;e;e;s;n;w;n;w;n;n;w;e;s;s;s;n;w;n;n;n;e;w;s;s;w;e;s;e;e;e;n;s;e;n;n;w;e;e;n;s;w;n;w;e;n;e;w;n;w;e;s;s;s;s;s;w;w;n;w;e;e;n;s;w;n;e;w;n;w;e;e;w;n;e;n;n";
    } else if (w.startsWith("华山村")) {
        go_path = "jh 3;n;e;w;s;w;e;s;e;n;s;w;s;e;s;n;w;w;n;s;e;s;s;w;n;s;e;s;e;w;nw;n;n;e;w;n;w;e;n;n;w;e;e;w;n";
    } else if (w.startsWith("华山")) {
        go_path = "jh 4;n;n;w;e;n;e;w;n;n;n;e;n;n;s;s;w;n;n;w;s;n;w;n;s;e;e;n;e;n;n;w;e;n;e;w;n;e;w;n;s;s;s;s;s;w;n;w;e;n;n;w;e;e;s;s;n;n;n;n;s;s;w;n";
    } else if (w.startsWith("扬州")) {
        go_path = "jh 5;n;w;w;n;s;e;e;e;w;n;w;e;e;w;n;w;e;n;w;e;n;w;w;s;s;n;n;n;n;w;n;n;n;s;s;s;e;e;w;n;s;s;s;e;e;e;n;n;n;s;s;w;n;e;n;n;s;s;e;n;n;w;n;n;s;s;w;s;s;e;e;s;w;s;w;n;w;e;e;n;n;e;w;w;e;n;n;s;s;s;s;w;n;w;e;e;w;n;w;w;n;s;e;e;n;e;s;e;s;s;s;n;n;n;w;n;w;w;s;n;w;n;w;e;e;w;n;n;w;n;s;e;e;s;n;w;n";
    } else if (w.startsWith("丐帮")) {
        go_path = "jh 6;event_1_98623439;ne;n;ne;ne;ne;sw;sw;sw;s;ne;ne;sw;sw;sw;s;w";
    } else if (w.startsWith("乔阴县")) {
        go_path = "jh 7;s;s;s;w;s;w;w;w;e;e;e;e;s;s;e;n;n;e;w;s;s;w;s;w;w;w;n;s;s;e;n;s;e;ne;s;e;n;e;s;e";
    } else if (w.startsWith("峨眉山")) {
        go_path = "jh 8;ne;e;e;e;e;w;n;s;s;n;w;w;w;sw;w;nw;n;n;n;n;w;e;se;nw;e;n;s;e;n;n;e;halt;n;n;n;e;e;w;w;w;n;n;n;w;w;s;e;w;s;e;w;w;e;n;w;e;n;w;w;n;s;sw;ne;e;e;n;e;w;w;e;n;e;w;w;e;n;w;w;w;n;n;n;s;s;s;e;e;e;e;e;e;e;e;e;w;w;s;e;w;w;e;s;e;w;w;e;s;e;e;w;w;s;e;w;w;e;s;e;w;w;e;n;n;w;w;n;n;n;n;w;n;s;w;e;s;n;e;n;n;n;n;s;s;nw;nw;n;n;s;s;se;sw;w;nw;w;e;se;e;ne;se;ne;se;s;se;nw;n;nw;ne;n;s;se;e";
    } else if (w.startsWith("恒山")) {
        go_path = "jh 9;n;w;e;n;e;w;n;w;e;n;e;w;n;n;n;w;n;s;s;n;e;e;n;s;e;w;w;n;n;w;n;e;w;n;n;w;e;n";
    } else if (w.startsWith("武当山")) {
        go_path = "jh 10;w;n;n;w;w;w;n;n;n;n;n;w;n;s;e;n;n;n;n;s;s;s;s;e;e;s;n;e;e;w;w;w;w;s;e;e;e;e;s;e;s;e;n;s;s;n;e;e;n;s;e;w;s;s;s";
    } else if (w.startsWith("晚月庄")) {
        go_path = "jh 11;e;e;n;e;s;sw;se;s;s;s;s;s;s;se;s;n;ne;n;nw;w;w;s;s;w;e;se;e;n;n;n;n;n;n;w;n;s;w;n;w;e;s;w;w;e;s;n;e;s;w;e;s;e;e;e;w;w;w;w;w;n;s;s;n;e;s;n;e;s;w;w;e;e;e;s;s;e;w;w;s;e;e;w;w;n;e;w;w;w;e;n;n;n;s;w;e;s;e;s;n;n;e";
    } else if (w.startsWith("水烟阁")) {
        go_path = "jh 12;n;e;w;n;n;n;s;w;n;n;e;w;s;nw;e;n;s;e;sw;n;s;s;e";
    } else if (w.startsWith("少林寺")) {
        go_path = "jh 13;e;s;s;w;w;w;e;e;n;n;w;n;w;w;n;s;e;e;n;e;w;w;e;n;n;e;w;w;e;n;n;e;w;w;e;n;n;e;w;w;e;n;n;e;s;s;s;s;s;s;s;s;n;n;n;n;n;n;n;n;w;w;s;s;s;s;s;s;s;s;n;n;n;n;n;n;n;n;e;n;e;w;w;e;n;w;n";
    } else if (w.startsWith("唐门")) {
        go_path = "jh 14;e;w;w;n;n;n;n;s;w;n;s;s;n;w;n;s;s;n;w;n;s;s;n;w;e;e;e;e;e;s;n;e;n;e;w;n;n;s;ask tangmen_tangmei;ask tangmen_tangmei;e;event_1_8413183;event_1_39383240;e;s;e;n;w;n;n";
    } else if (w.startsWith("青城山")) {
        go_path = "jh 15;s;s;e;w;w;n;s;e;s;e;w;w;w;n;s;s;s;n;n;w;w;w;n;s;w;e;e;e;e;e;e;s;e;w;w;e;s;e;w;s;w;s;ne;s;s;s;e;s;n;w;n;n;n;n;n;n;n;n;n;n;nw;w;nw;n;s;w;s;s;s;halt;w;w;w;w;n;e;n;s;s;s;n;e;n;e;w;w;e;n;s;s;e";
    } else if (w.startsWith("逍遥林")) {
        go_path = "jh 16;s;s;s;s;e;e;e;s;w;w;w;w;w;e;n;s;s;n;e;e;n;n;s;s;s;s;n;n;e;n;s;s;s;n;n;e;e;n;n;e;event_1_5221690;s;w;event_1_57688376;n;n;w;w;e;n;s;e;e;n;s;e;n;n;w;n;e;n";
    } else if (w.startsWith("开封")) {
        go_path = "jh 17;sw;s;sw;nw;ne;sw;se;ne;n;ne;n;w;e;e;s;n;w;n;w;n;n;s;s;e;e;e;n;n;s;s;s;n;w;s;s;s;w;e;e;n;s;e;e;w;w;s;n;w;s;w;e;n;n;n;n;w;n;e;w;n;w;e;e;w;n;e;n;n;n;s;s;s;w;s;s;s;s;s;e;s;s;s;e;w;s;s;w";
    } else if (w.startsWith("光明顶")) {
        go_path = "jh 18;e;w;w;n;s;e;n;nw;n;n;w;e;n;n;n;ne;n;n;w;e;e;w;n;w;e;e;w;n;n;w;w;s;n;n;e;e;e;e;s;se;se;e;w;nw;nw;w;w;n;w;w;n;n;e;nw;se;e;e;e;se;e;w;sw;s;w;w;n;e;w;n;e;w;w;e;n;n;n;n;w;e;n;event_1_90080676;event_1_56007071;ne;n";
    } else if (w.startsWith("全真教")) {
        go_path = "jh 19;s;s;s;sw;s;e;n;nw;n;n;n;n;e;w;w;e;n;e;n;s;e;e;w;n;n;s;s;w;w;w;w;w;w;s;n;e;s;n;e;e;e;n;n;w;w;s;s;n;n;w;s;s;n;n;w;n;n;n;n;n;n;e;n;e;e;n;n;s;s;e;e;e;e;s;e;s;s;s;n;w;n;s;s;s;s;w;s;n;w;n;e;n;n;n;s;w;n;n;n;s;s;s;w;n;s;w;n;s;s;s;e;n;n;e;s;s;s;w";
    } else if (w.startsWith("古墓")) {
        go_path = "jh 20;s;s;n;n;w;w;s;e;s;s;s;s;s;sw;sw;s;e;se;nw;w;s;w;e;e;w;s;s;w;w;e;s;sw;ne;e;s;s;w;w;e;e;s;n;e;e;e;e;s;e;w;n;w;n;n;s;e;w;w;s;n;n;n;n;s;e;w;w";
    } else if (w.startsWith("白驮山")) {
        go_path = "jh 21;nw;s;n;ne;ne;sw;n;n;ne;w;e;n;n;w;w;e;e;s;s;sw;s;s;sw;w;n;s;w;nw;e;w;nw;nw;n;w;sw;ne;e;s;se;se;n;e;w;n;n;w;e;n;n;w;w;w;n;n;n;n;s;s;s;e;e;e;n;s;s;n;e;e;e;w;ne;sw;n;n;w;e;e;e;w;w;n;nw;se;ne;w;e;e;w;n";
    } else if (w.startsWith("嵩山")) {
        go_path = "jh 22";
    } else if (w.startsWith("寒梅庄")) {
        go_path = "jh 23";
    } else if (w.startsWith("泰山")) {
        go_path = "jh 24";
    } else if (w.startsWith("大旗门")) {
        go_path = "jh 25";
    } else if (w.startsWith("大昭寺")) {
        go_path = "jh 26";
    } else if (w.startsWith("魔教")) {
        go_path = "jh 27";
    }
    go_steps(go_path);
}

function luoyangBankFunc() {
    go("jh 2;n;n;n;n;n;n;;n;e");
    go('tzjh_lq');
    go('home');
}

var kfMonitor = 0;
var kfKind = "";
function listenKFFunc() {
    if (kfMonitor==0){
        kfMonitor=1;
        btnList["跨服监听"].innerText = '停止跨服';
    }else if (kfMonitor==1){
        kfMonitor=0;
        btnList["跨服监听"].innerText = '跨服监听';
    }
}

var kf = "";
var killtimes = 0;

function kuafuFlyFunc() {
    console.log(kf);
    if (kf.match("find_qinglong_road.*") != null)
        eval(kf);
    else
        go_ql(kf);
    //killHongMingTargetFunc();
}

function zhengli(itemName, itemid, action, limit) {
    var m = $('#out table:eq(2) tr span:contains('+itemName+')');
    if (m != null) {
        m = m.parent().parent().find('span').filter(function () {
            return new RegExp("[0-9]+").test($(this).text());
        });
        var num = m.text().match(/(\d+)/);
        if (num == null)
            return;
        //   var exec = "clickButton('items "+action+" "+itemid+"')";
        var exec = "items "+action+" "+itemid;

        console.log(exec);
        num = parseInt(num[0]);
        if (action == "put_store")
            num = 1;
        if (limit != null)
            num = limit;
        for (var i = 0; i < num; ++i) {
            //      eval(exec);
            go(exec);
        }
    }
}
//=========================================================
function kbb(){
 go('home;shop;shopinfo 19;shop buy shop19_N_10;shop buy shop19_N_10;shop buy shop19_N_10;shop buy shop19_N_10;shop buy shop19_N_10;shop buy shop19_N_10;shop buy shop19_N_10;shop buy shop19_N_10;shop buy shop19_N_10;shop buy shop19_N_10;prev;shopinfo 18;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;shop buy shop18_N_10;prev;shopinfo 17;shop buy shop17_N_10;shop buy shop17_N_10;shop buy shop17_N_10;shop buy shop17_N_10;shop buy shop17_N_10');
    }
//=========================================================
 var clb_time;
 var clb_flag=true;
function clearBag(){
    clb_flag=false;
    go('items',0);
    clearInterval(clb_time);
    clb_time=setInterval(clearitem,200);
}
var items_use='高级乾坤袋特级乾坤袋 青凤纹绶 热血印 风云宝箱高级狂暴丹特级狂暴丹保险卡特级大还丹高级大还丹小还丹百年紫芝百年灵草特级乾坤再造丹高级乾坤再造丹';
var items_store='侠客令高级突破丹九花玉露丸百宝令迷题卡 腊八粥 腊百草美酒元宵 年糕 兰陵美酒 神鸢宝箱 云梦青『隐武竹笺』高级突破加速卡舞鸢尾超级突破加速卡 优昙仙露 朱果 高级突破秘术『神匠宝箱』冰糖葫芦『秘籍木盒』 茉莉汤 狗年礼券曜玉宝箱空识卷轴玫瑰花青木宝箱烧香符周年礼券鱼竿鱼饵江湖令谜题令正邪令状元贴白银宝箱黄金宝箱铂金宝箱装备打折卡碎片黄金钥匙鎏金黑玉锥曜玉钥匙铂金钥匙赤璃钥匙';
var items_study=' 左手兵刃研习 武穆遗书';
var items_splite='金狮盾 星河剑 翎眼赤护 青鸾护臂 苍狼护臂 宝玉甲 天寒匕 貂皮斗篷 白玉腰束 无心匕 玄武盾 月光宝甲 沧海护腰 夜行披风虎皮腰带红光匕金丝甲羊毛斗篷破军盾金丝甲疯魔杖毒龙鞭玉清棍生死符霹雳掌套血屠刀残雪帽残雪戒残雪鞋残雪手镯残雪项链金丝宝甲衣';
var items_sell='';
function clearitem(){
    var t=$("tr[bgcolor]:contains(万两)").siblings();
    if(t.length>0){
        clearInterval(clb_time);
        for(var i=0;i<t.length;i++){
            if(t.eq(i)[0].innerText.replace(/\s+/g,"")!=""){
                var a=t.eq(i).find('td')[0].innerText.replace('\n',"");
                var b=parseInt(t.eq(i).find('td')[1].innerText.match(/\d+/g)[0]);
                var c=t[i].getAttribute('onclick').split("'")[1].split("info ")[1];
                if(items_use.indexOf(a)!=-1){
                    console.log("使用："+a+" 数量："+b);
                    for(j=0;j<b;j++){go('items use '+c);
                                    }
                }else if(items_store.indexOf(a)!=-1){
                    console.log("存仓库："+a+" 数量："+b);
                    go('items put_store '+c);
                }else if(items_study.indexOf(a)!=-1){
                    console.log("学习："+a+" 数量："+b);
                    for(j=0;j<b;j++){go('study '+c);
                                    }
                }else if(items_sell.indexOf(a)!=-1){
                    console.log("卖掉："+a+" 数量："+b);
                    for(j=0;j<Math.floor(b/10);j++){
                        go('items sell '+c+'_N_10');
                    }
                    for(j=0;j<(b%10);j++){
                        go('items sell '+c);
                    }
                }else if(items_splite.indexOf(a)!=-1){
                    console.log("分解："+a+" 数量："+b);
                    for(j=0;j<Math.floor(b/10);j++){
                        go('items splite '+c+'_N_10');
                    }
                    for(j=0;j<(b%10);j++){
                        go('items splite '+c);
                    }
                }
                if(a.indexOf('】璞玉')!=-1){
                    console.log("存仓库："+a+" 数量："+b);
                    go('items put_store '+c);
                }
                if(a.indexOf('】青玉')!=-1){
                    console.log("存仓库："+a+" 数量："+b);
                    go('items put_store '+c);
                }
                if(a.indexOf('】墨玉')!=-1){
                    console.log("存仓库："+a+" 数量："+b);
                    go('items put_store '+c);
                }
                //                if(a.indexOf('残页』')!=-1){
                //                    console.log("存仓库："+a+" 数量："+b);
                //                    go('items put_store '+c);
                //                }
               // if(a.indexOf('宝石')!=-1){
               //     console.log("存仓库："+a+" 数量："+b);
               //     go('items put_store '+c);
               // }
             //  if(a.indexOf('基础')!=-1||a.indexOf('中级')!=-1||a.indexOf('进阶')!=-1||a.indexOf('衫')!=-1||a.indexOf('劲服')!=-1||a.indexOf('袈裟')!=-1||a.indexOf('吹雪')!=-1||a.indexOf('圣衣')!=-1||a.indexOf('道袍')!=-1||a.indexOf('水烟阁')!=-1){
               //    console.log("卖掉："+a+" 数量："+b);
                 //  for(j=0;j<b;j++){go('items sell '+c);
                   //                }
               // }
            }
        }
       // go('use_all');
        go('use_all_pantao');
    }
  }
//===================================================
function createButton(btnName,func){
    btnList[btnName]=document.createElement('button');
    var myBtn = btnList[btnName];
    myBtn.innerText = btnName;
    myBtn.style.position = 'absolute';
    myBtn.style.right = '2px';
    myBtn.style.top = currentPos + 'px';
    currentPos = currentPos + delta;
    myBtn.style.width = buttonWidth;
    myBtn.style.height = buttonHeight;
    myBtn.addEventListener('click', func);

    // 按钮加入窗体中
    document.body.appendChild(myBtn);
}

/**
window.go = function(dir) {
    console.debug("开始执行：", dir);
    var d = dir.split(";");
    for (var i = 0; i < d.length; i++)
        clickButton(d[i], 0);
};
*/

//回主页-------------------------
function GoHomeFunc(){
    clickButton('home');     //回主页
}

function getQLNPCTargetCode(){
    var peopleList = $(".cmd_click3");
    var thisonclick = null;
    var targetNPCListHere = [];
    var countor= 0;

    for(var i=0; i < peopleList.length; i++) { // 从第一个开始循环
        // 打印 NPC 名字，button 名，相应的NPC名
        thisonclick = peopleList[i].getAttribute('onclick');
        if (QLNPCList.contains(peopleList[i].innerText)){
            var targetCode = thisonclick.split("'")[1].split(" ")[1];
            //           console.log("发现NPC名字：" +  peopleList[i].innerText + "，代号：" + targetCode);
            targetNPCListHere[countor] = peopleList[i];
            countor = countor +1;
        }
    }
    // targetNPCListHere 是当前场景所有满足要求的NPC button数组
    if (currentNPCIndex >= targetNPCListHere.length){
        currentNPCIndex = 0;
    }
    if (targetNPCListHere.length > 0){
        thisonclick = targetNPCListHere[currentNPCIndex].getAttribute('onclick');
        var targetCode = thisonclick.split("'")[1].split(" ")[1];
        console.log("准备杀目标NPC名字：" + targetNPCListHere[currentNPCIndex].innerText + "，代码：" + targetCode +"，目标列表中序号：" + (currentNPCIndex ));
        clickButton('kill ' + targetCode); // 点击杀人
        setTimeout(detectkillQLNPCInfo,200); // 200 ms后获取杀人情况，是满了还是进入了
    }
}
function detectkillQLNPCInfo(){
    var corpseInfo = $('span').text();
    if (corpseInfo.slice(-15) == "已经太多人了，不要以多欺少啊。"){
        currentNPCIndex = currentNPCIndex + 1;
    }else{
        currentNPCIndex = 0;
    }
}

var getcorpseIntervalFunc =  null;
var currentNPCIndex = 0;
//var corpseNPCList = [];
function getcorpseTargetFunc(){
    zdskill =  mySkillLists;
    //var corpseNPCLists = prompt("请输入要摸的目标","月老的尸体");
    // corp = corpseNPCLists
    //var corpseNPCLists = prompt("请输入要摸的目标","月老的尸体");
    var corpseNPCList = [];
    corpseNPCList[0] = prompt("请输入要摸的目标","月老的尸体");
    if (getcorpseTargetButton.innerText == '摸月老'){
        currentNPCIndex = 0;
        console.log("开始摸月老目标NPC！");
        skillLists = mySkillLists;
        getcorpseTargetButton.innerText ='停摸';
        getcorpseIntervalFunc = setInterval(getcorpse, 500);

    }else{
        console.log("停止摸月老目标NPC！");
        getcorpseTargetButton.innerText ='摸月老';
        clearInterval(getcorpseIntervalFunc);
    }
}

function getcorpse(){
    //	  clickButton('go east');
    if ($('span').text().slice(-7) == "不能杀这个人。"){
        currentNPCIndex = currentNPCIndex + 1;
        console.log("不能杀这个人！");
        //        return;
    }
    getcorpseTargetCode();
    setTimeout(ninesword, 200);
    if($('span:contains(胜利)').text().slice(-3)=='胜利！' || $('span:contains(战败了)').text().slice(-6)=='战败了...'){
        currentNPCIndex = 0;
        console.log('杀人一次！');
        go('prev_combat');
    }
}
function getcorpseTargetCode(){
    var peopleList = $(".cmd_click3");
    var thisonclick = null;
    var targetNPCListHere = [];
    var countor= 0;

    for(var i=0; i < peopleList.length; i++) { // 从第一个开始循环
        // 打印 NPC 名字，button 名，相应的NPC名
        thisonclick = peopleList[i].getAttribute('onclick');
        if (corpseNPCList.contains(peopleList[i].innerText)){
            var targetCode = thisonclick.split("'")[1].split(" ")[1];
            //           console.log("发现NPC名字：" +  peopleList[i].innerText + "，代号：" + targetCode);
            targetNPCListHere[countor] = peopleList[i];
            countor = countor +1;
        }
    }
    // targetNPCListHere 是当前场景所有满足要求的NPC button数组
    if (currentNPCIndex >= targetNPCListHere.length){
        currentNPCIndex = 0;
    }
    if (targetNPCListHere.length > 0){
        thisonclick = targetNPCListHere[currentNPCIndex].getAttribute('onclick');
        var targetCode = thisonclick.split("'")[1].split(" ")[1];
        console.log("准备杀目标NPC名字：" + targetNPCListHere[currentNPCIndex].innerText + "，代码：" + targetCode +"，目标列表中序号：" + (currentNPCIndex ));
        clickButton('get ' + targetCode); // 点击杀人
        setTimeout(detectgetcorpseInfo,200); // 200 ms后获取杀人情况，是满了还是进入了
    }
}
function detectgetcorpseInfo(){
    var corpseInfo = $('span').text();
    if (corpseInfo.slice(-15) == "已经太多人了，不要以多欺少啊。"){
        currentNPCIndex = currentNPCIndex + 1;
    }else{
        currentNPCIndex = 0;
    }
}
Array.prototype.contains = function (obj) {
    var i = this.length;
    while (i--) {
        if (this[i] === obj) {
            return true;
        }
    }
    return false;
};

//3新门派------------------------
function sanmenpaiFunc(){
    go('jh 2;n;n;e;s;luoyang317_op1;look_npc luoyang_luoyang17;go_hjs;go_hjs go;se;se;ne;w;n;ne;ne');
}

function LiaoShangFunc(){
    go('recovery;recovery;recovery;recovery;recovery;recovery;recovery;recovery;recovery;recovery');
    clickButton('score');    // 状态
    var qixue = $('span.out3:contains(【气血】)').text();
    var neili = $('span.out3:contains(【内力】)').text();
    var qixueNum = qixue.match(/\d{1,}/g);// 气血
    var neiliNum = neili.match(/\d{1,}/g);// 内力
    var isMax = qixueNum[1] - qixueNum[0];
    var useNum =Math.floor((neiliNum[1] -neiliNum[0])/ 5000);//吃药次数
    if(isMax!=0)//缺血
    {
        if(useNum<0){useNum = 0;}
        for (var i=0; i<useNum; i++)  // 补内力
        {
            go('items use snow_qiannianlingzhi');
        }
        for (var i=0; i<15; i++)   // 补血
        {
            go('recovery');
        }
    }
    else
    {
        if(useNum<0){useNum = 0;}
        for (var i=0; i<useNum; i++)  // 补内力
        {
            go('items use snow_qiannianlingzhi');
        }
    }
    go('golook_room');    // 观察


    for (var i=0; i<10; i++)
    {
        //clickButton('recovery');
        go('recovery');
    }

}

// 清谜题 -----------------------------------------------

function clearPuzzleFunc(){
    go('auto_tasks cancel');
}

// 吃千年灵芝-------------------------------------------
function userMedecineFunc(){
    for (var i=0; i<5; i++)
    {
        go('items use snow_qiannianlingzhi');
    }
}




// 买千年灵芝-------------------------------------------
function buyMedecineFunc(){
    go('jh 1;e;n;n;n;w;');
    buy1MedecineFunc();
}
function  buy1MedecineFunc(){
    var num  = 0;
    if(!( num  = prompt("请输入购买数量，只能输入10的倍数：","10"))){
        return;
    }
    num  = parseInt(num/10);
    for(var i=0; i < num; i++) { // 从第一个开始循环
        go('buy /map/snow/obj/qiannianlingzhi_N_10 from snow_herbalist'); //买灵芝
    }
}

String.prototype.trim = function (char, type) { // 去除字符串中，头部或者尾部的指定字符串
    if (char) {
        if (type == 'left') {
            return this.replace(new RegExp('^\\'+char+'+', 'g'), '');
        } else if (type == 'right') {
            return this.replace(new RegExp('\\'+char+'+$', 'g'), '');
        }
        return this.replace(new RegExp('^\\'+char+'+|\\'+char+'+$', 'g'), '');
    }
    return this.replace(/^\s+|\s+$/g, '');
};
// 自动答题
function answerQuestionFunc(){
    clickButton('look_room');
    clickButton('question', 0);
}
//青龙监听
var QLtrigger=0;
function listenQLFunc(){
    if (QLtrigger==0){
        QLtrigger=1;
        btnList["青龙监听"].innerText = '停止青龙';
    }else if (QLtrigger==1){
        QLtrigger=0;
        btnList["青龙监听"].innerText = '青龙监听';
    }
}
//游侠监听
var YXtrigger=0;
function listenYXFunc(){
    if (YXtrigger==0){
        YXtrigger=1;
        btnList["游侠监听"].innerText = '停止游侠';
    }else if (YXtrigger==1){
        YXtrigger=0;
        btnList["游侠监听"].innerText = '游侠监听';
    }
}
var lastcmd ;
var lastpuzzlelink;
var lastpuzzleid;
var lastpuzzlename;
var singlePuzzleMsg = '';
(function (window) {

    function QinglongMon() {
        this.dispatchMessage = function(b) {
            var type = b.get("type"), subType = b.get("subtype");
            if (type == "main_msg") {
                var msg = g_simul_efun.replaceControlCharBlank(b.get("msg"));
                if( msg.indexOf("今日已达到谜题数量限制") > -1 && Puzzletrigger == 1 )
                {
                    listenPuzzleFunc();

                }

                if (iBatchAskStart >= 1){
                    //     console.log( msg );

                    if( msg.indexOf("练武奇才") > -1 ){
                        //  每隔5秒检查 检查
                        setTimeout(PuzzleNPCAsk,1000);
                    }

                    if (msg.indexOf('所接谜题过多') > -1){
                        iBatchAskStart = 0;
                        //     listenPuzzleFunc();// 自动处理任务模式
                        eval("clickButton('task_quest')") ;//显示任务列表
                        return;
                    }
                    if(msg.indexOf("已不在这") > -1 || msg.indexOf("你想干什么") > -1 || msg.indexOf("挺有兴致地跟你聊了起来") > -1  ||  msg.indexOf("盯着你看了一会儿") > -1  || msg.indexOf("你在这做什么") > -1  || msg.indexOf("江湖上好玩吗") > -1  || msg.indexOf("似乎想问你天气怎么样") > -1  ){

                        setTimeout(PuzzleNextFunc,500);

                    }
                    if (msg.indexOf('find_task_road') > -1){


                        //      console.log( iBatchAskStart );
                        if (iBatchAskStart >= iValidPuzzleNum){
                            //谜题接满5个开始处理任务
                            iBatchAskStart = 0;
                            listenPuzzleFunc();// 自动处理任务模式
                            eval("clickButton('task_quest')") ;//显示任务列表
                            return;

                        }else {
                            iBatchAskStart = iBatchAskStart +1;

                            setTimeout(PuzzleNextFunc,300);


                            // 如果全部NPC已经完成  开始处理任务

                            //否则继续找下个NPC接谜题

                        }
                    }
                }
                if (Puzzletrigger==1){

                    if (msg.indexOf('find_task_road') > -1){
                        //       console.log('迷题 - '  + msg );

                        //      var l=msg.match(/find_task_road( \w+)/);
                        if (msg.indexOf('谜题2') > -1){
                            imultiplePuzzle = 1;
                            singlePuzzleMsg = msg.split('\n')[0];
                            msg= singlePuzzleMsg.toString();
                            //       console.log('迷题 n- '  + msg );
                            //         console.log('迷题 1- '  + singlePuzzleMsg );
                            //          return;


                        }else{
                            if  (msg.indexOf('谜题1') > -1){
                                imultiplePuzzle = 0;
                                //          return;
                            }
                        }

                        lastpuzzlelink=msg.match( /(find[\w|-]+\s[\w|-]+)/g);  //    /find[\w|-]+\s[\w|-]+/g           /(find_\w+\s\w*)/g   //获取buttonclick 事件名称
                        lastpuzzleid=msg.match(/\s([\w|-]+)/g);   //获取谜题任务NPC的ID
                        var l= msg.match(/\s[\w|-]+\S([\u4e00-\u9fa5|-]+)/g);   //获取谜题任务NPC的NAME
                        lastpuzzlename=l;
                        //       console.log("NAME：" +  lastpuzzlename);


                        //           console.log('迷题 n- '  + msg );
                        //        console.log("NAME：" +  l);

                        var lstmppuzzlename;

                        //       console.log('迷题 n- '  + (l.length) );
                        if ( lastpuzzlelink ) {
                            if ( lastpuzzlelink.length  == 2) {
                                //  console.log("NAME：" +  l);

                                for(j=0;j<l.length;j++){

                                    lastpuzzlename[j]=l[j].match(/[\u4e00-\u9fa5|-]+/g);

                                    //     console.log("NAME1：" +  lstmppuzzlename);
                                    if( lastpuzzlename[j].toString().indexOf('-') >-1){

                                        lstmppuzzlename=lastpuzzlename[j].toString().split('-');
                                        //  console.log("NAME1：" +  lstmppuzzlename);
                                        lastpuzzlename[j]=lstmppuzzlename[lstmppuzzlename.length - 1];

                                    }

                                }
                                //  console.log("NAME2：" +  lastpuzzlename);


                                eval("clickButton('" + lastpuzzlelink[1] + "')") ;// go( l[1]);

                            }else if (lastpuzzlelink.length ==1)  {
                                //  lastpuzzlename[0]=l[0].match(/([\u4e00-\u9fa5|-]+)/g);
                                lastpuzzlename[1]= lastpuzzlename[0];
                                for(j=0;j<lastpuzzlename.length;j++){
                                    lastpuzzlename[j]=l[j].match(/[\u4e00-\u9fa5|-]+/g);
                                    if(lastpuzzlename[j].toString().indexOf('-') >-1){

                                        lstmppuzzlename=lastpuzzlename[j].toString().split('-');

                                        lastpuzzlename[j]=lstmppuzzlename[lstmppuzzlename.length - 1];
                                        //           lastpuzzlename[j].replace(/([^,]*)/g, "$1");
                                        //           lastpuzzlename[j]=lastpuzzlename[j].toString().split('-')[1].toString();
                                    }

                                }
                                lastpuzzlename[1]= lastpuzzlename[0];
                                //            console.log('link- '  + lastpuzzlelink[0] );
                                //           console.log('ID- '  + lastpuzzlename[0]);
                                //           console.log('NAME- '  + lastpuzzlename[0] );
                                eval("clickButton('" + lastpuzzlelink[0] + "')") ;// go( l[0]);

                            }else{

                                for(j=0;j<lastpuzzlename.length;j++){
                                    lastpuzzlename[j]=l[j].match(/[\u4e00-\u9fa5|-]+/g);
                                    if(lastpuzzlename[j].toString().indexOf('-') >-1){
                                        lstmppuzzlename=lastpuzzlename[j].toString().split('-');

                                        lastpuzzlename[j]=lstmppuzzlename[lstmppuzzlename.length - 1];
                                    }

                                }
                                //                console.log('link- '  + lastpuzzlelink[0]+'--'+ lastpuzzlelink[1] +'--'+ lastpuzzlelink[2] );
                                //                  console.log('ID- '  + lastpuzzleid[0]+'--'+ lastpuzzleid[1] +'--'+ lastpuzzleid[2] );
                                //                   console.log('NAME- '  + lastpuzzlename[0]+'--'+ lastpuzzlename[1] +'--'+ lastpuzzlename[2] );
                                eval("clickButton('" + lastpuzzlelink[1] + "')") ;// go( l[1]);
                            }

                            for(j=0;j<lastpuzzlename.length;j++){




                                if( lastpuzzlename[j].toString().indexOf(',') >-1){

                                    lstmppuzzlename=lastpuzzlename[j].toString().split(',');
                                    //  console.log("NAME1：" +  lstmppuzzlename);
                                    lastpuzzlename[j]=lstmppuzzlename[lstmppuzzlename.length - 1];

                                }

                            }

                            lastcmd = msg;
                            //     lastpuzzlelink = l[0] ;
                            //     lastdeslink =  l[1] ;
                            igoodsteps =0;

                            //           console.log("谜题:" + '-'  + l[0] +  '+'  + l[1] );
                            //      console.log("谜题：" +  lastcmd);
                            //        console.log("LINK：" +  lastpuzzlelink);
                            //         console.log("ID：" +  lastpuzzleid);
                            //           console.log("NAME：" +  lastpuzzlename);


                            clearInterval(PuzzleActIntervalFunc);
                            PuzzleActIntervalFunc = setInterval(function(){ PuzzleActFunc(lastcmd ,lastpuzzlelink ,lastpuzzleid  , lastpuzzlename);}, 1000);
                            //   setTimeout(function(){ PuzzleActFunc(lastcmd ,lastsoulink ,lastdeslink  );},500);
                        }



                    }

                    if( msg.indexOf("完成谜题") > -1 ){
                        clearInterval(PuzzleActIntervalFunc);
                        var strfinishNum = msg.match(/完成谜题\((\d+)\//);
                        var strpuzzlename = msg.split('：')[1].split('，')[0];
                        var strexp = msg.match(/经验x(.*)/);
                        var strpotential=msg.match(/潜能x(.*)/);
                        var strmoney = msg.match(/银两x(.*)/);


                        // console.log('完成谜题:' + strfinishNum[1] + strpuzzlename +strexp[0] +strpotential[0]  +strmoney[0]);


                        var lexp= parseInt(strexp[1]);
                        if (strexp && lexp > 200000 ){
                            //clickButton('go_chat');
                            var city = btnList["迷题扫图"].innerText;
                            var txt = '城市：'+city+ '/n完成谜题(' + strfinishNum[1] +'/15)：'+ strpuzzlename +'/n' +strexp[0] + '/n'+strpotential[0] + '/n' + strmoney[0];
                            // var txt = '完成谜题:' + strpuzzlename +strexp[0] +strpotential[0]  +strmoney[0];
                            //$('#chat_msg').val(txt);
                            //clickButton('send_chat');
                            alert(txt);
                            console.log(txt);
                        }
                        if (parseInt(strfinishNum[1])<= 10){
                            iValidPuzzleNum =5;

                        }else{
                            iValidPuzzleNum = 15 - parseInt(strfinishNum[1]) ;
                        }
                        if (parseInt(strfinishNum[1]) ==15){
                            listenPuzzleFunc();

                        }else{
                            if (imultiplePuzzle ==1 ){
                                eval("clickButton('task_quest')") ;
                            }else{
                                //   setTimeout(PuzzleNextFunc,300);
                                if (iBatchAskModel == 1){
                                    setTimeout(NpcBatchAskStartFunc,300);
                                }else{
                                    setTimeout(PuzzleNextFunc,300);
                                }


                            }


                        }

                    }
                    if( msg.indexOf("我就不给，你又能怎样") > -1){
                        PuzzleActIntervalFunc = setInterval(function(){ PuzzleActFunc(lastcmd ,lastpuzzlelink ,lastpuzzleid  , lastpuzzlename);}, 1000);

                    }
                    //此人现在已不在这儿了
                    if(msg.indexOf("练武奇才") > -1){
                        //  每隔5秒检查 检查
                        setTimeout(PuzzleNPCAsk,1000);

                    }


                    if(msg.indexOf("已不在这") > -1 || msg.indexOf("你想干什么") > -1  || msg.indexOf("挺有兴致地跟你聊了起来") > -1  || msg.indexOf("盯着你看了一会儿") > -1  || msg.indexOf("你在这做什么") > -1  || msg.indexOf("江湖上好玩吗") > -1  || msg.indexOf("似乎想问你天气怎么样") > -1  ){

                        PuzzleNextFunc();

                    }
                    if( msg.indexOf("你现在没有接到谜题任务") > -1){
                        imultiplePuzzle = 0;
                    }

                }




            }

            if (type == "channel" && subType == "sys") {
                var msg = g_simul_efun.replaceControlCharBlank(b.get("msg"));
                if (msg.indexOf("【系统】青龙会组织：") > -1 || msg.indexOf("游侠会：") > 0) {
                    var l = msg.match(/系统】青龙会组织：(.*)正在(.*)施展力量，本会愿出(.*)的战利品奖励给本场战斗的最终获胜者。/);
                    if (l&&QLtrigger==1 && isContains(qlEquipList, l[3])) {
                        //      if (l&&QLtrigger==1 ) {
                        palyWarn();
                        QLNPCList[0]=l[1];
                        go_ql(l[2]);
                        killQLNPCTargetFunc();


                        //        alert('青龙:' + l[1] + " --- " + l [3] + "  " + l[2]);
                        return;
                    }

                    l = msg.match(/【系统】游侠会：听说(.*)出来闯荡江湖了，目前正在前往(.*)的路上。/);
                    if (l&&YXtrigger==1) {
                        if (l[1] == '龙儿'){

                            return;
                        }
                        QLNPCList[0]=l[1];
                        palyWarn();

                        console.log('游侠:' + l[1] + " --在-- " + l [2] );
                        go_yx(l[2]);
                        return;
                    }
                }
                var m;

                m = msg.match(/【系统】\[16-20区\](段老大).+(find_qinglong_road \d+)/);
                if (m != null) {
                    kfKind = "跨服逃犯";
                    kf = "clickButton('" + m[2] + "')";
                    if (kfMonitor == 1) {
                        kuafuFlyFunc();
                        killHongMingTargetFunc();
                    }
                }
                m = msg.match(/青龙会组织：\[16-20区\](.*)正在(.*)施展力量，本会愿出(.*)的战利品奖励给本场战斗的最终获胜者。/);
                if (m != null && m[3].match(/.*(碎片|斩龙|龙皮至尊甲衣|飞宇天怒刀|九天龙吟剑|小李飞刀|天罡掌套|乌金玄火鞭|开天宝棍|达摩杖).*/) != null) {
                    kfKind = "跨服青龙";
                    kf = m[2];
                    if (kfMonitor == 1) {
                        kuafuFlyFunc();
                        killHongMingTargetFunc();
                    }
                }
                m = msg.match(/荣威镖局：\[16-20区\]花落云/);
                if (m != null) {
                    msg = $('span:contains(荣威镖局:[16-20区]花落云)').find('a').attr('href');
                    console.log("kf:"+msg);
                    kfKind = "跨服镖车";
                    m = msg.match(/(find_qinglong_road \d+)/);
                    kf = "clickButton('" + m[1] + "')";
                    if (kfMonitor == 1) {
                        kuafuFlyFunc();
                        killHongMingTargetFunc();
                    }
                }
                m = msg.match(/【系统】(.*)对着(.*)叫道：喂，老匹夫！想要消灾赶紧掏钱，要不然老子可不客气了！/);
                if (m != null &&  m[1].match(/.*(段老大|二娘).*/) != null && ipositiveKill == 1 ) {
                    console.log("出现目标NPC:"+m[1]);
                    QLNPCList[0]=m[1];
                    if (m[2]=="杨掌柜"){
                        go_ql("桑邻药铺");

                    }else if (m[2]=="王铁匠"){
                        go_ql("打铁铺子");

                    }else if (m[2]=="柳绘心"){
                        go_ql("书房");

                    }else if (m[2]=="客商"){
                        go_ql("南市");
                    }else if (m[2]=="柳小花"){
                        go_ql("桃花别院");

                    }else if (m[2]=="卖花姑娘"){
                        go_ql("北大街");

                    }else if (m[2]=="刘守财"){
                        go_ql("钱庄");

                    }else if (m[2]=="方寡妇"){
                        go_ql("厅堂");

                    }else if (m[2]=="朱老伯"){
                        go_ql("祠堂大门");

                    }else if (m[2]=="方老板"){
                        go_ql("杂货铺");
                    }
                    killQLNPCTargetFunc();
                    return;



                }

            }
        };
    }

    function palyWarn(){
        //base64码警报声
        var snd = new Audio("data:audio/wav;base64,UklGRoBnAABXQVZFZm10IBAAAAABAAEARKwAAIhYAQACABAAZGF0YVxnAAAAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PYAABwJLRImG/sjoiwPNTc9D0WOTKpTWFqSYE5mhWsxcEt0zXe1ev18on6jf/9/tH/Dfi599nofeKt0oHADbNpmKmH9WlpUSU3URQQ+4zV9LdskChwUEwUK6QDN97ruv+Xl3DnUxsuWw7a7LbQHrU2mCKA/mvqUQJAYjIaIj4U3g4GBb4ADgD2AHYGigsqEkYf1ivKOgJOcmD6eX6T3qv6xabkxwUrJqtFG2hPjBuwS9S3+SgdeEF0ZOiLrKmUzmzuFQxZLRlILWV1fM2WFak1vhHMmdy16lXxbfn1/+n/QfwF/jH11e714aHV7cfts7WdYYkNct1W7TllHmj+JNzAvmSbQHeEU1gu8Ap/5ifCI56fe8dVxzTTFQr2ntW2unac/oV2b/ZUnkeGMMIkahqKDy4GYgAuAJIDjgEeCToT2hjyKGo6MkoyXE50co5ypjbDmt5y/pcf4z4nYTeE56kHzWvx4BY8Okhd3IDIpuDH9OfZBmkneULpXI14SZH9pZG64cnh2nnkmfA1+UH/uf+Z/N3/kfe17VXkfdlBy7W37aIBjhF0PVylQ20guQSw54DBVKJUfrRanDY8EcftZ8lPpa+Cr1yDP1MbSviW316/xqHyigJwFlxOSsI3hiauGE4QcgsmAGoASgLCA84Hag2KGiIlIjZyRgZbum92hRqgir2a2Cr4DxkjOztaJ327ocfGI+qYDvwzHFbMedycIMFs4ZEAaSHNPZFbkXO1idGh0beZxxHUKebJ7uX0df9x/9X9ofzV+XnzmedB2H3PZbgNqo2TBXmNYk1FZSr5CzDqPMg8qWSF4GHcPYQZE/Sr0H+sw4mfZ0NB3yGbAp7hFsUmqvaOonROYBZOFjpiKQ4eLhHSC/4AwgAaAg4ClgWuD04XaiHyMs5B7lc2ao6D1prqt6rR7vGXEm8wV1cbdo+ai77b40wHuCvoT7Ry6JVYutjbPPpdGAk4JVaFbwmFkZ4BsDnELdW94NntefeN+w3/9f5F/f37JfHF6enfoc8BvBmvBZfhfs1n5UtNLSkRqPDo0xysbI0EaRhEzCBf/+/Xs7PbjJduD0h3K/MEsureypqsDpdaeJpn9k2CPVYvhhwqF0oI9gUyAAYBdgF6BA4NLhTOItYvPj3uUsplun6ilVqxys/G6ycLxyl7TBdza5NPt5PY=");
        snd.play();
        //		if(qinglong_need > 0){
        //			setTimeout(palyWarn,1000);
        //		}
    }

    var qlMon = new QinglongMon;

    var ql_p = {
        '书房': 1,
        '打铁铺子': 2,
        '桑邻药铺': 3,
        '南市': 4,
        '桃花别院': 5,
        '绣楼': 6,
        '北大街': 7,
        '钱庄': 8,
        '杂货铺': 9,
        '祠堂大门': 10,
        '厅堂': 11
    };
    window.go_ql = function(w) {
        zx(ql_p[w]);
    };
    function go_yx(w) {
        // 雪亭镇  洛阳 华山村 华山 扬州 丐帮 乔阴县 峨眉山 恒山 武当山 晚月庄 水烟阁 少林寺 唐门 青城山 逍遥林 开封 光明顶 全真教 古墓 白驮山
        //穿装备
        //go("wield weapon_moke_unarmed8;wield weapon_moke_unarmed9;wield weapon_moke_unarmed10;wield weapon_moke_sword10;wear equip_moke_head10");
        steps=0;
        if (w.startsWith("雪亭镇")) {
            go_path = "jh 1;e;s;w;w;e;s;n;e;e;ne;ne;sw;sw;n;w;n;e;e;n;s;e;e;n;s;e;w;s;n;w;w;w;w;w;e;n;w;e;n;w;e;e;e;w;w;n;n;s;e;w;w";
        } else if (w.startsWith("洛阳")) {
            go_path = "jh 2;n;n;e;s;n;w;n;e;s;n;w;w;e;n;w;s;w;e;n;e;e;s;n;w;n;w;n;n;w;e;s;s;s;n;w;n;n;n;e;w;s;s;w;e;s;e;e;e;n;s;e;n;n;w;e;e;n;s;w;n;w;e;n;e;w;n;w;e;s;s;s;s;s;w;w;n;w;e;e;n;s;w;n;e;w;n;w;e;e;w;n;e;n;n";
        } else if (w.startsWith("华山村")) {
            go_path = "jh 3;n;e;w;s;w;e;s;e;n;s;w;s;e;s;n;w;w;n;s;e;s;s;w;n;s;e;s;e;w;nw;n;n;e;w;n;w;e;n;n;w;e;e;w;n";
        } else if (w.startsWith("华山")) {
            go_path = "jh 4;n;n;w;e;n;e;w;n;n;n;e;n;n;s;s;w;n;n;w;s;n;w;n;s;e;e;n;e;n;n;w;e;n;e;w;n;e;w;n;s;s;s;s;s;w;n;w;e;n;n;w;e;e;s;s;n;n;n;n;s;s;w;n";
        } else if (w.startsWith("扬州")) {
            go_path = "jh 5;n;w;w;n;s;e;e;e;w;n;w;e;e;w;n;w;e;n;w;e;n;w;w;s;s;n;n;n;n;w;n;n;n;s;s;s;e;e;w;n;s;s;s;e;e;e;n;n;n;s;s;w;n;e;n;n;s;s;e;n;n;w;n;n;s;s;w;s;s;e;e;s;w;s;w;n;w;e;e;n;n;e;w;w;e;n;n;s;s;s;s;w;n;w;e;e;w;n;w;w;n;s;e;e;n;e;s;e;s;s;s;n;n;n;w;n;w;w;s;n;w;n;w;e;e;w;n;n;w;n;s;e;e;s;n;w;n";
        } else if (w.startsWith("丐帮")) {
            go_path = "jh 6;event_1_98623439;ne;n;ne;ne;ne;sw;sw;sw;s;ne;ne;sw;sw;sw;s;w";
        } else if (w.startsWith("乔阴县")) {
            go_path = "jh 7;s;s;s;w;s;w;w;w;e;e;e;e;s;s;e;n;n;e;w;s;s;w;s;w;w;w;n;s;s;e;n;s;e;ne;s;e;n;e;s;e";
        } else if (w.startsWith("峨眉山")) {
            go_path = "jh 8;ne;e;e;e;e;w;n;s;s;n;w;w;w;sw;w;nw;n;n;n;n;w;e;se;nw;e;n;s;e;n;n;e;halt;n;n;n;e;e;w;w;w;n;n;n;w;w;s;e;w;s;e;w;w;e;n;w;e;n;w;w;n;s;sw;ne;e;e;n;e;w;w;e;n;e;w;w;e;n;w;w;w;n;n;n;s;s;s;e;e;e;e;e;e;e;e;e;w;w;s;e;w;w;e;s;e;w;w;e;s;e;e;w;w;s;e;w;w;e;s;e;w;w;e;n;n;w;w;n;n;n;n;w;n;s;w;e;s;n;e;n;n;n;n;s;s;nw;nw;n;n;s;s;se;sw;w;nw;w;e;se;e;ne;se;ne;se;s;se;nw;n;nw;ne;n;s;se;e";
        } else if (w.startsWith("恒山")) {
            go_path = "jh 9;n;w;e;n;e;w;n;w;e;n;e;w;n;n;n;w;n;s;s;n;e;e;n;s;e;w;w;n;n;w;n;e;w;n;n;w;e;n";
        } else if (w.startsWith("武当山")) {
            go_path = "jh 10;w;n;n;w;w;w;n;n;n;n;n;w;n;s;e;n;n;n;n;s;s;s;s;e;e;s;n;e;e;w;w;w;w;s;e;e;e;e;s;e;s;e;n;s;s;n;e;e;n;s;e;w;s;s;s";
        } else if (w.startsWith("晚月庄")) {
            go_path = "jh 11;e;e;n;e;s;sw;se;s;s;s;s;s;s;se;s;n;ne;n;nw;w;w;s;s;w;e;se;e;n;n;n;n;n;n;w;n;s;w;n;w;e;s;w;w;e;s;n;e;s;w;e;s;e;e;e;w;w;w;w;w;n;s;s;n;e;s;n;e;s;w;w;e;e;e;s;s;e;w;w;s;e;e;w;w;n;e;w;w;w;e;n;n;n;s;w;e;s;e;s;n;n;e";
        } else if (w.startsWith("水烟阁")) {
            go_path = "jh 12;n;e;w;n;n;n;s;w;n;n;e;w;s;nw;e;n;s;e;sw;n;s;s;e";
        } else if (w.startsWith("少林寺")) {
            go_path = "jh 13;e;s;s;w;w;w;e;e;n;n;w;n;w;w;n;s;e;e;n;e;w;w;e;n;n;e;w;w;e;n;n;e;w;w;e;n;n;e;w;w;e;n;n;e;s;s;s;s;s;s;s;s;n;n;n;n;n;n;n;n;w;w;s;s;s;s;s;s;s;s;n;n;n;n;n;n;n;n;e;n;e;w;w;e;n;w;n";
        } else if (w.startsWith("唐门")) {
            go_path = "jh 14;e;w;w;n;n;n;n;s;w;n;s;s;n;w;n;s;s;n;w;n;s;s;n;w;e;e;e;e;e;s;n;e;n;e;w;n;n;s;ask tangmen_tangmei;ask tangmen_tangmei;e;event_1_8413183;event_1_39383240;e;s;e;n;w;n;n";
        } else if (w.startsWith("青城山")) {
            go_path = "jh 15;s;s;e;w;w;n;s;e;s;e;w;w;w;n;s;s;s;n;n;w;w;w;n;s;w;e;e;e;e;e;e;s;e;w;w;e;s;e;w;s;w;s;ne;s;s;s;e;s;n;w;n;n;n;n;n;n;n;n;n;n;nw;w;nw;n;s;w;s;s;s;halt;w;w;w;w;n;e;n;s;s;s;n;e;n;e;w;w;e;n;s;s;e";
        } else if (w.startsWith("逍遥林")) {
            go_path = "jh 16;s;s;s;s;e;e;e;s;w;w;w;w;w;e;n;s;s;n;e;e;n;n;s;s;s;s;n;n;e;n;s;s;s;n;n;e;e;n;n;e;event_1_5221690;s;w;event_1_57688376;n;n;w;w;e;n;s;e;e;n;s;e;n;n;w;n;e;n";
        } else if (w.startsWith("开封")) {
            go_path = "jh 17;sw;s;sw;nw;ne;sw;se;ne;n;ne;n;w;e;e;s;n;w;n;w;n;n;s;s;e;e;e;n;n;s;s;s;n;w;s;s;s;w;e;e;n;s;e;e;w;w;s;n;w;s;w;e;n;n;n;n;w;n;e;w;n;w;e;e;w;n;e;n;n;n;s;s;s;w;s;s;s;s;s;e;s;s;s;e;w;s;s;w";
        } else if (w.startsWith("光明顶")) {
            go_path = "jh 18;e;w;w;n;s;e;n;nw;n;n;w;e;n;n;n;ne;n;n;w;e;e;w;n;w;e;e;w;n;n;w;w;s;n;n;e;e;e;e;s;se;se;e;w;nw;nw;w;w;n;w;w;n;n;e;nw;se;e;e;e;se;e;w;sw;s;w;w;n;e;w;n;e;w;w;e;n;n;n;n;w;e;n;event_1_90080676;event_1_56007071;ne;n";
        } else if (w.startsWith("全真教")) {
            go_path = "jh 19;s;s;s;sw;s;e;n;nw;n;n;n;n;e;w;w;e;n;e;n;s;e;e;w;n;n;s;s;w;w;w;w;w;w;s;n;e;s;n;e;e;e;n;n;w;w;s;s;n;n;w;s;s;n;n;w;n;n;n;n;n;n;e;n;e;e;n;n;s;s;e;e;e;e;s;e;s;s;s;n;w;n;s;s;s;s;w;s;n;w;n;e;n;n;n;s;w;n;n;n;s;s;s;w;n;s;w;n;s;s;s;e;n;n;e;s;s;s;w";
        } else if (w.startsWith("古墓")) {
            go_path = "jh 20;s;s;n;n;w;w;s;e;s;s;s;s;s;sw;sw;s;e;se;nw;w;s;w;e;e;w;s;s;w;w;e;s;sw;ne;e;s;s;w;w;e;e;s;n;e;e;e;e;s;e;w;n;w;n;n;s;e;w;w;s;n;n;n;n;s;e;w;w";
        } else if (w.startsWith("白驮山")) {
            go_path = "jh 21;nw;s;n;ne;ne;sw;n;n;ne;w;e;n;n;w;w;e;e;s;s;sw;s;s;sw;w;n;s;w;nw;e;w;nw;nw;n;w;sw;ne;e;s;se;se;n;e;w;n;n;w;e;n;n;w;w;w;n;n;n;n;s;s;s;e;e;e;n;s;s;n;e;e;e;w;ne;sw;n;n;w;e;e;e;w;w;n;nw;se;ne;w;e;e;w;n";
        } else if (w.startsWith("嵩山")) {
            go_path = "jh 22";
        } else if (w.startsWith("寒梅庄")) {
            go_path = "jh 23";
        } else if (w.startsWith("泰山")) {
            go_path = "jh 24";
        } else if (w.startsWith("大旗门")) {
            go_path = "jh 25";
        } else if (w.startsWith("大昭寺")) {
            go_path = "jh 26";
        } else if (w.startsWith("魔教")) {
            go_path = "jh 27";
        }
        go_steps(go_path);
    }
    /*
    function go_yx(w){
        if (w.startsWith("雪亭镇")) {
            go("jh 1;e;n");
        } else if (w.startsWith("洛阳")) {
            go("jh 2;n;n");
        } else if (w.startsWith("华山村")) {
            go("jh 3;s;s");
        } else if (w.startsWith("华山")) {
            go("jh 4;n;n");
        } else if (w.startsWith("扬州")) {
            go("jh 5;n;n");
        } else if (w.startsWith("丐帮")) {
            go("jh 6;event_1_98623439;s");
        } else if (w.startsWith("乔阴县")) {
            go("jh 7;s;s;s");
        } else if (w.startsWith("峨眉山")) {
            go("jh 8;w;nw;n;n;n;n");
        } else if (w.startsWith("恒山")) {
            go("jh 9;n;n;n");
        } else if (w.startsWith("武当山")) {
            go("jh 10;w;n;n");
        } else if (w.startsWith("晚月庄")) {
            go("jh 11;e;e;s;sw;se;w");
        } else if (w.startsWith("水烟阁")) {
            go("jh 12;n;n;n");
        } else if (w.startsWith("少林寺")) {
            go("jh 13;n;n");
        } else if (w.startsWith("唐门")) {
            go("jh 14;w;n;n;n");
        } else if (w.startsWith("青城山")) {
            go("jh 15;s;s");
        } else if (w.startsWith("逍遥林")) {
            go("jh 16;s;s");
        } else if (w.startsWith("开封")) {
            go("jh 17;n;n");
        } else if (w.startsWith("明教")) {
            go("jh 18;n;nw;n;n");
        } else if (w.startsWith("全真教")) {
            go("jh 19;s;s");
        } else if (w.startsWith("古墓")) {
            go("jh 20;w;w");
        } else if (w.startsWith("白驮山")) {
            go("jh 21;nw;w");
        } else if (w.startsWith("嵩山")) {
            go("jh 22;n;n");
        } else if (w.startsWith("寒梅庄")) {
            go("jh 23");
        } else if (w.startsWith("泰山")) {
            go("jh 24");
        } else if (w.startsWith("大旗门")) {
            go("jh 25");
        } else if (w.startsWith("大昭寺")) {
            go("jh 26");
        } else if (w.startsWith("魔教")) {
            go("jh 27");
        }

        random_move();
    }
    */

    function random_move() {
        var v = Math.random();
        if (v < 0.25) go("e");
        else if (v < 0.5) go("w");
        else if (v < 0.75) go("s");
        else go("n");
    }

    function zx(x) {
        x = parseInt(x);
        console.debug(x);

        if (x == 1) {
            go("jh 1;e;n;e;e;e;e;n");
        } else if (x == 2) {
            go("jh 1;e;n;n;w");
        } else if (x == 3) {
            go("jh 1;e;n;n;n;w");
        }

        if (x == 4) {
            go("jh 2;n;n;e");
        }

        if (x == 5) {
            go("jh 2;n;n;n;n;w;s");
        }
        if (x == 6) {
            go("jh 2;n;n;n;n;w;s;w");
        }
        if (x == 7) {
            go("jh 2;n;n;n;n;n;n;n");
        }
        if (x == 8) {
            go("jh 2;n;n;n;n;n;n;;n;e");
        }

        if (x == 9) {
            go("jh 3;s;s;e");
        }
        if (x == 10) {
            go("jh 3;s;s;w");
        }
        if (x == 11) {
            go("jh 3;s;s;w;n");
        }

    }


    function MyMap(){
        this.elements = [];
        this.size = function() {
            return this.elements.length;
        };
        this.isEmpty = function() {
            return 1 > this.elements.length;
        };
        this.clear = function() {
            this.elements = [];
        };
        this.put = function(a, b) {
            for (var c = !1, d = 0; d < this.elements.length; d++)
                if (this.elements[d].key == a) {
                    c = !0;
                    this.elements[d].value = b;
                    break;
                }
            !1 == c && this.elements.push({
                key: a,
                value: b
            })
        };
        this.remove = function(a) {
            var b = !1;
            try {
                for (var c = 0; c < this.elements.length; c++)
                    if (this.elements[c].key == a)
                        return this.elements.splice(c, 1), !0;
            } catch (d) {
                b =
                    !1;
            }
            return b;
        };
        this.get = function(a) {
            try {
                for (var b = 0; b < this.elements.length; b++)
                    if (this.elements[b].key == a)
                        return this.elements[b].value;
            } catch (c) {
                return null;
            }
        };
        this.copy = function(a) {
            null == a && (a = new Map);
            try {
                for (var b = 0; b < this.elements.length; b++)
                    a.put(this.elements[b].key, this.elements[b].value);
                return a;
            } catch (c) {
                return null;
            }
        };
        this.element = function(a) {
            return 0 > a || a >= this.elements.length ? null : this.elements[a];
        };
        this.containsKey = function(a) {
            var b = !1;
            try {
                for (var c = 0; c < this.elements.length; c++)
                    if (this.elements[c].key ==
                        a) {
                        b = !0;
                        break;
                    }
            } catch (d) {
                b = !1;
            }
            return b;
        };
        this.containsValue = function(a) {
            var b = !1;
            try {
                for (var c = 0; c < this.elements.length; c++)
                    if (this.elements[c].value == a) {
                        b = !0;
                        break;
                    }
            } catch (d) {
                b = !1;
            }
            return b;
        };
        this.values = function() {
            for (var a = [], b = 0; b < this.elements.length; b++)
                a.push(this.elements[b].value);
            return a;
        };
        this.keys = function() {
            for (var a = [], b = 0; b < this.elements.length; b++)
                a.push(this.elements[b].key);
            return a;
        };
    }

    function Question() {
        this.answers = new MyMap;
        this.answers.put('金项链可以在哪位npc那里获得', "d");

        this.answer = function(a) {
            //          alert("答案是：" + a);
            go("question " + a);
            //            go("question");
        };

        this.dispatchMessage = function(b) {
            var type = b.get("type"), msg= b.get("msg");
            if (type == "show_html_page" && msg.indexOf("知识问答第") > 0) {
                console.log(msg);
                if (msg.indexOf("回答正确！") > 0) {
                    //     sleep(500);
                    go("question");
                    return;
                }

                var q = this.answers.keys();
                for (var i in q) {
                    var k = q[i];

                    if (msg.indexOf(k) > 0) {
                        this.answer(this.answers.get(k));
                        break;
                    }
                }

                //                else if (msg.indexOf("正邪任务一天能做几次") > 0) this.answer("b")

            }
        };
    }

    var question = new Question;
    function Trigger(r, h, c, n) {
        this.regexp = r;
        this.handler = h;
        this.class = c;
        this.name = n;

        this.enabled = true;

        this.trigger = function(line) {
            if (!this.enabled) return;

            if (!this.regexp.test(line)) return;

            console.log("触发器: " + this.regexp + "触发了");
            var m = line.match(this.regexp);
            this.handler(m);
        };

        this.enable = function() {
            this.enabled = true;
        };

        this.disable = function() {
            this.enabled = false;
        };

    }

    jh = function(w) {
        if (w == 'xt') w = 1;
        if (w == 'ly') w = 2;
        if (w == 'hsc') w = 3;
        if (w == 'hs') w = 4;
        if (w == 'yz') w = 5;
        if (w == 'gb') w = 6;
        if (w == 'qy') w = 7;
        if (w == 'em') w = 8;
        if (w == 'hs2') w = 9;
        if (w == 'wd') w = 10;
        if (w == 'wy') w = 11;
        if (w == 'sy') w = 12;
        if (w == 'sl') w = 13;
        if (w == 'tm') w = 14;
        if (w == 'qc') w = 15;
        if (w == 'xx') w = 16;
        if (w == 'kf') w = 17;
        if (w == 'gmd') w = 18;
        if (w == 'qz') w = 19;
        if (w == 'gm') w = 20;
        if (w == 'bt') w = 21;
        if (w == 'ss') w = 22;
        if (w == 'mz') w = 23;
        if (w == 'ts') w = 24;


        go("jh " + w, 0);
        //       sleep(500);
    };


    function Triggers() {
        this.allTriggers = [];

        this.trigger = function(line) {
            var t = this.allTriggers.slice(0);
            for (var i = 0, l = t.length; i < l; i++) {
                t[i].trigger(line);
            }
        };

        this.newTrigger = function(r, h, c, n) {
            var t = new Trigger(r, h, c, n);
            if (n) {
                for (var i = this.allTriggers.length - 1; i >= 0; i--) {
                    if (this.allTriggers[i].name == n) this.allTriggers.splice(i, 1);
                }
            }

            this.allTriggers.push(t);

            return t;
        };

        this.enableTriggerByName = function(n) {
            for (var i = this.allTriggers.length - 1; i >= 0; i--) {
                t = this.allTriggers[i];
                if (t.name == n) t.enable();
            }
        };

        this.disableTriggerByName = function(n) {
            for (var i = this.allTriggers.length - 1; i >= 0; i--) {
                t = this.allTriggers[i];
                if (t.name == n) t.disable();
            }
        };

        this.enableByCls = function(c) {
            for (var i = this.allTriggers.length - 1; i >= 0; i--) {
                t = this.allTriggers[i];
                if (t.class == c) t.enable();
            }
        };

        this.disableByCls = function(c) {
            for (var i = this.allTriggers.length - 1; i >= 0; i--) {
                t = this.allTriggers[i];
                if (t.class == c) t.disable();
            }
        };

        this.removeByCls = function(c) {
            for (var i = this.allTriggers.length - 1; i >= 0; i--) {
                t = this.allTriggers[i];
                if (t && t.class == c) this.allTriggers.splice(i, 1);
            }
        };

        this.removeByName = function(n) {
            for (var i = this.allTriggers.length - 1; i >= 0; i--) {
                t = this.allTriggers[i];
                if (t.name == n) this.allTriggers.splice(i, 1);
            }
        };
    }

    window.triggers = new Triggers;

    triggers.newTrigger(/似乎以下地方藏有宝物(.*)/, function(m) {
        m = m[1].split(/\d+/);
        var bl_found = false;
        for (i = 0, l = m.length; i < l; i++) {
            var a = m[i];
            console.log(a);
            if (/一片翠绿的草地/.test(a)) {
                jh('ly');
                go('n;n;n;n;n;e;e;n;n;n;n;n;w;dig go');
                bl_found = true;
                break;
            }
        }
        if (bl_found) go("cangbaotu_op1");
        //      window.setTimeout('go("cangbaotu_op1")', 3000);
    }, "", "cbt");



    window.game = this;

    window.attach = function() {
        var oldWriteToScreen = window.writeToScreen;
        window.writeToScreen = function(a, e, f, g) {
            oldWriteToScreen(a, e, f, g);
            a = a.replace(/<[^>]*>/g, "");
            triggers.trigger(a);
        };

        webSocketMsg.prototype.old = gSocketMsg.dispatchMessage;

        gSocketMsg.dispatchMessage = function(b) {
            this.old(b);
            qlMon.dispatchMessage(b);
            question.dispatchMessage(b);
        };
    };
    attach();

})(window);
String.prototype.trim = function (char, type) { // 去除字符串中，头部或者尾部的指定字符串
    if (char) {
        if (type == 'left') {
            return this.replace(new RegExp('^\\'+char+'+', 'g'), '');
        } else if (type == 'right') {
            return this.replace(new RegExp('\\'+char+'+$', 'g'), '');
        }
        return this.replace(new RegExp('^\\'+char+'+|\\'+char+'+$', 'g'), '');
    }
    return this.replace(/^\s+|\s+$/g, '');
};


//自动战斗--------------------------
function AutoKillFunc(){
    if(btnList["自动战斗"].innerText  == '自动战斗'){
        AutoKill1Func();
        btnList["自动战斗"].innerText  = '手动战斗';}
    else{clearKill2();
         {btnList["自动战斗"].innerText  = '自动战斗';}
        }

    function AutoKill1Func(){
        // 间隔500毫秒查找比试一次
        AutoKill1FuncIntervalFunc = setInterval(AutoKill1,1000);
    }

    function clearKill2(){
        clearInterval(AutoKill1FuncIntervalFunc);
    }

    function AutoKill1(){
        ninesword();
        if($('span.outbig_text:contains(战斗结束)').length>0){
            clickButton('prev_combat');
        }
    }
}


//无脑摸尸体--------------------------------
//AutoGetFunc();
function AutoGetFunc(){
    if(btnList["摸尸体"].innerText  == '摸尸体'){
        var AutoGet_targetName = "尸体";
        AutoGet1Func();
        btnList["摸尸体"].innerText  = '不摸了';}
    else{clearGet();
         {btnList["摸尸体"].innerText  = '摸尸体';}
        }

    function AutoGet1Func(){
        AutoGet1IntervalFunc = setInterval(AutoGet1,1000);
    }

    function clearGet(){
        clearInterval(AutoGet1IntervalFunc);
    }

    function AutoGet1(){
        $("button.cmd_click3").each(
            function(){
                if(isContains($(this).html() , AutoGet_targetName))
                    eval($(this).attr("onclick").replace("look_item corpse","get corpse"));
            });
    }
}

//战斗调用通用脚本----------------------------------------------------
var banSkills = "天师灭神剑|茅山道术";
function ninesword(){
    zdskill = mySkillLists;
    //console.log(zdskill);
    setTimeout(ninesword1,1000);
    if($('span.outbig_text:contains(战斗结束)').length>0){
        clickButton('prev_combat');
    }
}

function ninesword1(){
    zdskill = mySkillLists;
    if (myname != '我是谁' && myMaxKee != 0) {
        var elem = $('td:contains('+myname+')');
        if (elem != null) {
           elem = elem.find('span.outkee_text');
           if (elem != null) {
               var curKee = parseInt(elem.text());
               var p = curKee * 100 / myMaxKee;
               if (p < 65) {
                   console.log("wound : " + p);
                   for(var i = 1;i < 7;i++) {
                        skillName = $('#skill_'+i).children().children().text();
                       if(skillName !== "" && isContains(forceList, skillName)) {
                             clickButton('playskill '+i);
                        return;
                         }
                  }
                }
            }
       }
     }

    // 如果找到设置的技能则释放
    for(var i = 1;i < 7;i++){
        skillName = $('#skill_'+i).children().children().text();
        if(skillName !== "" && isContains(zdskill, skillName)){
            //console.log(i);
            clickButton('playskill '+i);
            return;
        }
    }
    // 如果没找到设置技能，随便用一个非招bb的技能
    for(i = 1;i < 7;i++){
        skillName = $('#skill_'+i).children().children().text();
        if(skillName !== "" && !isContains(banSkills, skillName)){
            //console.log(skillName);
            clickButton('playskill '+i);
            return;
        }
    }
}


//-------------------------分割线-----------

//逃跑-------------------------
function escapeFunc(){
    if(btnList["逃跑"].innerText  == '逃跑'){
        AutoEscapeFunc();
        btnList["逃跑"].innerText  = '取消逃跑';}
    else{clearEscape();
         {btnList["逃跑"].innerText  = '逃跑';}
        }

    function AutoEscapeFunc(){
        // 间隔500毫秒逃跑一次
        AutoEscapeFuncIntervalFunc = setInterval(AutoEscape,500);
    }

    function clearEscape(){
        clearInterval(AutoEscapeFuncIntervalFunc);
    }

    function AutoEscape(){
        go('escape');     //逃跑
        if($('span.outbig_text:contains(战斗结束)').length>0){
            clearEscape();
            btnList["逃跑"].innerText  = '逃跑';
            go('prev_combat');
        }
        else if($('button.cmd_combat_byebye').length===0){
            clearEscape();
            btnList["逃跑"].innerText  = '逃跑';
            go('prev_combat');
        }
    }
}
//-------------------------分割线-----------

//全地图搜索
function go_steps(dir) {
    $("button.cmd_click3").each(
        function(){
            if(isContains($(this).html() , QLNPCList[0] )){
                //读取目标ID
                youxia_id = $(this).attr("onclick").split("'")[1].split(" ")[1];
                console.log("发现游侠NPC名字：" +  QLNPCList[0] + "，代号：" + youxia_id);
            }
        }
    );
    var d = dir.split(";");
    if(d[steps]=='halt') {
        steps += 1;
        return;
    }
    if(steps < d.length && youxia_id == null){
        clickButton(d[steps]);
        steps += 1;
        setTimeout(function(){go_steps(dir);},200);
    }else{
        steps=0;
        if (youxia_id != null){
            //go( 'look_npc ' + youxia_id );
            youxia_id = null;
            killQLNPCTargetFunc();
        }
    }
}



//-------------------------分割线-----------
//正邪杀二娘,段老大 刷正气 positive


function positiveKill() {

    if (ipositiveKill==0){
        ipositiveKill=1;
        inegativeKill=0;
        btnList["刷正气"].innerText = '停刷正气';
        //     btnList["刷邪气"].innerText = '刷邪气';

    }else if (ipositiveKill==1){
        ipositiveKill=0;
        btnList["刷正气"].innerText = '刷正气';
    }

}


//刷邪气 negative 查血量

function negativeKill() {

    var peopleList = $(".cmd_click3");
    var thisonclick = null;
    var targetNPCListHere = [];
    var countor = 0;
    var elem;
    var curKee = 0;
    var maxKee = 0;
    var p = 1;
    var val;
    var m = null;
    console.log("刷邪气 " + String( peopleList.length )  );

    for(var i=0; i < peopleList.length; i++) { // 从第一个开始循环
        // 打印 NPC 名字，button 名，相应的NPC名
        thisonclick = peopleList[i].getAttribute('onclick');


        var targetCode = thisonclick.split("'")[1].split(" ")[1];

        //    console.log("发现NPC名字：" +  peopleList[i].innerText + "，代号：" + targetCode  + (targetCode.indexOf("bad")));
        if ( targetCode.indexOf("bad") != -1  ){


            clickButton('watch_vs ' + targetCode);

            //   console.log("目标NPC: " +peopleList[i].innerText + "进入观战");
            if(isContains($('#out2').html(),'vs21')){

                console.log("目标NPC: " + peopleList[i].innerText + "血量1:"  + $('#vs_hp21').children().children().text() );
                curKee = $('#vs_hp21').children().children().text();
                console.log("目标NPC: " + peopleList[i].innerText + "血量1:"  + curKee  );
                if( curKee >  690000 ){
                    //       console.log("目标NPC: " + peopleList[i].innerText + "血量1:"  + curKee  );

                    //     go('escape');
                    return;
                }

            }else
            {

            }
            clickButton('escape');
            /*
            elem = null;
            elem = $('td:contains('+peopleList[i].innerText+')');
            if (elem != null) {

              val = elem.find('span.vader21').attr('style');

              if (val == null)
                val = elem.find('span.vader22').attr('style');
              if (val == null)
                val = elem.find('span.vader23').attr('style');
              if (val == null)
                val = elem.find('span.vader24').attr('style');
              if (val != null) {
                m = val.match(/width: (\d+)\./);
           //     console.log("NPC：" +  peopleList[i].innerText + "，血量1：" + m[1]);
                p = parseInt(m[1]);
              }else
              {
                  p = 100;
             //     console.log("NPC：" +  peopleList[i].innerText + "，血量1：100");
              }

              elem = elem.find('span.outkee_text');
              if (elem != null) {
                curKee = parseInt(elem.text());
                  */

            maxKee=  curKee  ;
            //   console.log("NPC：" +  peopleList[i].innerText + "，血量1：" + elem.text() );


            if ( maxKee > 690000 ) {
                //可以刷邪气

                targetNPCListHere[countor] = peopleList[i];
                countor = countor +1;

            }


        }
    }





    // targetNPCListHere 是当前场景所有满足要求的NPC button数组
    if (currentNPCIndex >= targetNPCListHere.length){
        currentNPCIndex = 0;
    }
    if (targetNPCListHere.length > 0){
        thisonclick = targetNPCListHere[currentNPCIndex].getAttribute('onclick');
        var targetCode = thisonclick.split("'")[1].split(" ")[1];
        console.log("准备杀目标NPC名字：" + targetNPCListHere[currentNPCIndex].innerText + "，代码：" + targetCode +"，目标列表中序号：" + (currentNPCIndex ));
        clickButton('kill ' + targetCode); // 点击杀人
        setTimeout(detectkillQLNPCInfo,200); // 200 ms后获取杀人情况，是满了还是进入了
    }


}


///-------------------------分割线-----------
//接谜题

//clickButton('room_sousuo') 搜索此地
itargetNPCOrder = 0 ;
iNPCOrder = 0 ;
function PuzzleFunc(){



    var peopleList = $(".cmd_click3");
    var thisonclick = null;
    var targetNPCListHere = [];
    var countor= 0;

    for(var i=0; i < peopleList.length; i++) { // 从第一个开始循环
        // 打印 NPC 名字，button 名，相应的NPC名

        thisonclick = peopleList[i].getAttribute('onclick');

        var targetCode = thisonclick.split("'")[1].split(" ")[1];

        if (typeof(targetCode) != "undefined" && targetCode.indexOf("bad") == -1 ) {


            console.log("发现NPC名字：" +  peopleList[i].innerText + "，代号：" + targetCode);
            targetNPCListHere[iNPCOrder] = peopleList[i];
            iNPCOrder = iNPCOrder +1;

            if (iNPCOrder < itargetNPCOrder ) return ;

            itargetNPCOrder = iNPCOrder;
            go('ask '+ targetCode);

            //   clickButton('task_quest');

            if ( isContains($('span:contains(find_task_road)').text().slice(-14), 'find_task_road')){

                return;
            }

            if ( isContains($('span:contains(今日已达到谜题数量)').text().slice(-12), '今日已达到谜题数量限制。')){
                alert('当前用户15个谜题已经完成，请更换新用户进行谜题任务/n 任务序号:' + (itargetNPCOrder));
                return ;
            }
            if ( isContains($('span:contains(盯着你看了一会儿。)').text(), '盯着你看了一会儿。')){

            }
            if ( isContains($('span:contains(睁大眼睛望着你，似乎想问你天气怎么样。)').text(), '睁大眼睛望着你，似乎想问你天气怎么样。')){
                alert('没有谜题' );
                //    return

            }
        }

    }



}

///-------------------------分割线-----------
//谜题处理

//var PuzzleActIntervalFunc =  null;

// ask fight kill give  get  npc_datan

var igoodsteps=0;

var PuzzleActIntervalFunc = null;

function PuzzleActFunc( lstrmsg , lsrslink , lsrsid, lsrsname ){
    clearInterval(PuzzleActIntervalFunc);
    //打探打探情况
    //可前去寻找
    var lsacttype;


    //    var lslog="";
    //   console.log("处理谜题：" +  lstrmsg);

    //    console.log("link：" +  lsrslink);
    //    console.log("ID：" +  lsrsid);
    //   console.log("Name1：" +  lsrsname[1]);
    /*
    for (k=0; k < lsrslink.length ; k++){
        lslog= lslog +lsrslink[k]+ "--"
    }
    console.log("link：" +  lslog);
     lslog="";
    for (k=0; k < lsrsid.length ; k++){
        lslog= lslog +lsrsid[k]+ "--"
    }
    console.log("ID：" +  lslog);
     lslog="";
     for (k=0; k < lsrsname.length ; k++){
        lslog= lslog +lsrsname[k]+ "--"
    }
    console.log("Name：" +  lslog);

*/
    if (Puzzletrigger !=1 ){
        return;
    }


    var peopleList = $(".cmd_click3");
    var thisonclick = null;
    var targetNPCListHere = [];
    var countor= 0;
    var lsrteval= null ;
    var lsnpcname ="";
    if  (lstrmsg.indexOf("可前去寻找") > -1 ){

        lsrteval = "clickButton('room_sousuo')";


    }

    if  ( ( lstrmsg.indexOf("好想要") > -1  || lstrmsg.indexOf("可否帮忙找来") > -1) && igoodsteps == 2 ){
        go( lsrslink[0]);
        igoodsteps = igoodsteps + 1;

    }



    for(var i=0; i < peopleList.length; i++) { // 从第一个开始循环
        // 打印 NPC 名字，button 名，相应的NPC名

        thisonclick = peopleList[i].getAttribute('onclick');
        if (thisonclick != null && thisonclick.split("'")[1].split(" ")[0] == 'look_item'  ) {

            if (lsrsname[1] == peopleList[i].innerText ){ //要寻找地上的物品

                lsrteval = "clickButton('get " +  thisonclick.split("'")[1].split(" ")[1]  + "')";

            }

        }

        if (thisonclick != null && thisonclick.split("'")[1].split(" ")[0] == 'look_npc'  ) {

            var targetCode = thisonclick.split("'")[1].split(" ")[1];

            //     console.log("发现NPC名字：" +  peopleList[i].innerText + "，代号：" + targetCode +lsrsname[1]+'>>' + lsrsname[1].indexOf(peopleList[i].innerText) );


            if (typeof(targetCode) != "undefined" && targetCode.indexOf("bad") == -1 &&  targetCode.indexOf("eren") == -1   && targetCode.indexOf("taofan") == -1 &&  targetCode.indexOf("bukuai") == -1 ){

                //     console.log("发现NPC名字：" +  peopleList[i].innerText + "，代号：" + targetCode);
                if (lstrmsg.indexOf("打探打探") > -1 && lsrsname[1]==peopleList[i].innerText ){
                    lsrteval = "clickButton('npc_datan " +  targetCode  + "')";
                }else if  (lstrmsg.indexOf("可前去打探一番") > -1 && lsrsname[1]==peopleList[i].innerText ){
                    //             console.log("打探：" +  peopleList[i].innerText + "，代号：" + targetCode);

                    lsrteval = "clickButton('npc_datan " +  targetCode  + "')";


                }else if  (lstrmsg.indexOf("可前去寻找") > -1 ){

                    lsrteval = "clickButton('room_sousuo')";


                }else if (lstrmsg.indexOf("去替我要回来吧") > -1 && (lsrsname[1]==peopleList[i].innerText || lsrsname[2]==peopleList[i].innerText )){

                    lsrteval = "clickButton('fight " +  targetCode  + "')";


                }else if  (lstrmsg.indexOf("去替我要回来可好") > -1 && lsrsname[1]==peopleList[i].innerText ){

                    if (peopleList[i].innerText == '大松鼠' || peopleList[i].innerText == '流氓' ||  peopleList[i].innerText == '小混混'   ) {
                        lsrteval = "clickButton('kill " +  targetCode  + "')";
                    }else{
                        lsrteval = "clickButton('fight " +  targetCode  + "')";
                    }

                }else if  (lstrmsg.indexOf("替我去教训教训") > -1 && lsrsname[1]==peopleList[i].innerText ){

                    lsrteval = "clickButton('fight " +  targetCode  + "')";

                }else if  (lstrmsg.indexOf("尝尝厉害") > -1 && lsrsname[1]==peopleList[i].innerText ){

                    lsrteval = "clickButton('fight " +  targetCode  + "')";

                }else if  (lstrmsg.indexOf("见识见识厉害") > -1 && lsrsname[1]==peopleList[i].innerText ){

                    lsrteval = "clickButton('fight " +  targetCode  + "')";

                }else if  (lstrmsg.indexOf("交差了") > -1 &&  lsrsname[0]==peopleList[i].innerText ){

                    lsrteval = "clickButton('ask " +  targetCode  + "')";


                }else if  (lstrmsg.indexOf("回去告诉") > -1 && lsrsname[0]==peopleList[i].innerText ){

                    lsrteval = "clickButton('ask " +  targetCode  + "')";


                }else if  (lstrmsg.indexOf("商量一点事情") > -1 && lsrsname[1]==peopleList[i].innerText ){

                    lsrteval = "clickButton('ask " +  targetCode  + "')";


                }else if  (lstrmsg.indexOf("回去转告") > -1 && lsrsname[0]==peopleList[i].innerText  ){

                    lsrteval = "clickButton('ask " +  targetCode  + "')";


                }else if  (lstrmsg.indexOf("我有个事情想找") > -1 && lsrsname[1]==peopleList[i].innerText ){

                    lsrteval = "clickButton('ask " +  targetCode  + "')";


                }else if  (lstrmsg.indexOf("可否帮忙找来") > -1 ){//蓝玫瑰  ,或者杀了拿东西 ，然后 返回lsrslink  GIVE

                    /* console.log("步骤:" + (igoodsteps));
                     if (igoodsteps == 0){
                         lsrteval = "clickButton('kill " +  targetCode  + "')";
                         igoodsteps = 1;


                     }else if (igoodsteps == 1){ //捡东西






                     } else if (igoodsteps == 2){ //返回
                  //       go( lsrslink);
                  //       igoodsteps = igoodsteps + 1;
                     }
                     else if (igoodsteps == 3){ //返回
                         lsrteval = "clickButton('give " +  targetCode  + "')";
                         igoodsteps =0;
                         clearInterval(PuzzleActIntervalFunc);
                     }




*/
                }else if  (lstrmsg.indexOf("好想要") > -1 ){//蓝玫瑰  ,或者杀了拿东西 ，然后 返回lsrslink  GIVE

                    /*console.log("步骤:" + (igoodsteps));
                     if (igoodsteps == 0){
                         lsrteval = "clickButton('kill " +  targetCode  + "')";
                         igoodsteps = 1;


                     }else if (igoodsteps == 1){ //捡东西






                     } else if (igoodsteps == 2){ //返回
                    //     go( lsrslink);
                     //    igoodsteps = igoodsteps + 1;
                     }
                     else if (igoodsteps == 3){ //返回
                         lsrteval = "clickButton('give " +  targetCode  + "')";
                         igoodsteps =0;
                         clearInterval(PuzzleActIntervalFunc);
                     }

*/

                }else if  (lstrmsg.indexOf("去杀了他") > -1 && lsrsname[1]==peopleList[i].innerText &&  lsrsname[1]!="龙儿"    ){

                    lsrteval = "clickButton('kill " +  targetCode  + "')";


                }else if  (lstrmsg.indexOf("真想杀掉他") > -1 && lsrsname[1]==peopleList[i].innerText &&  lsrsname[1]!="龙儿" ){

                    lsrteval = "clickButton('kill " +  targetCode  + "')";


                }


                if (lsrteval) {
                    //   console.log(lsrteval);
                    eval(lsrteval);
                    if (lsrteval.indexOf("kill") > -1){

                        ninesword();
                    }
                    return;
                }

                //    eval(lsrteval);




                //       go('ask '+ targetCode);
            }


        }

    }
    if (lsrteval) {
        //     console.log(lsrteval);
        eval(lsrteval);
    }

    PuzzleActIntervalFunc = setInterval(function(){ PuzzleActFunc(lastcmd ,lastpuzzlelink ,lastpuzzleid  , lastpuzzlename);}, 1000);




}


///-------------------------分割线-----------
//测试地图
var gstrNpcPath;
var gmapNPCList = [];  //NPC 列表
var gmapNPCPath = [];  //NPC 地图路径
var tempNPCList = [];  //零时数组 ，走地图时重复记录NPC ID的问题
var gmapNPCCount=0;  //记录 NPC数量
var iPuzzleOrders = -1 ;//迷题NPC进度
var gstrMapPath="";


function GetNPCStart(){

    //  go('home');
    clickButton('home');     //回主页
    //   WhoAmIFunc();

    if(btnList["自动战斗"].innerText  == '自动战斗'){
        AutoKillFunc();
    }


    var w = null ;
    //雪亭镇  洛阳 华山村 华山 扬州 丐帮 乔阴县 峨眉山 恒山 武当山 晚月庄 水烟阁 少林寺 唐门 青城山 逍遥林 开封 光明顶 全真教 古墓 白驮山
    if (! (w=prompt("请输入迷题地图名次","雪亭镇"))){
        return;
    }
    GetNPCStartMap(w);




}


///-------------------------分割线-----------
//产生地图NPC路径

function GetNPCPath(dir){
    var peopleList = $(".cmd_click3");
    var thisonclick = null;

    for(var i=0; i < peopleList.length; i++) { // 从第一个开始循环
        // 打印 NPC 名字，button 名，相应的NPC名

        thisonclick = peopleList[i].getAttribute('onclick');
        if (thisonclick != null && thisonclick.split("'")[1].split(" ")[0] == 'look_npc'  ) {

            var targetCode = thisonclick.split("'")[1].split(" ")[1];
            //  console.log("发现NPC名字：" +  peopleList[i].innerText + "，代号：" + targetCode + "，动作：" + thisonclick.split("'")[1].split(" ")[0]);

            if (isContains(qxNpcList , peopleList[i].innerText )) {

            }else{

                if (typeof(targetCode) != "undefined" && targetCode.indexOf("bad") == -1 &&  targetCode.indexOf("eren") == -1   && targetCode.indexOf("taofan") == -1 &&  targetCode.indexOf("bukuai") == -1 )
                {
                    if(tempNPCList.contains(targetCode)){

                    }else{
                        console.log("发现NPC名字：" + (gmapNPCCount +1) + ":" + peopleList[i].innerText + "，代号：" + targetCode);
                        tempNPCList[gmapNPCCount]=  targetCode ;
                        if (gstrNpcPath == ''){
                            gmapNPCList[gmapNPCCount] = peopleList[i].innerText + ';' + targetCode ;
                            gmapNPCPath[gmapNPCCount] = '';

                        }else
                        {
                            gmapNPCList[gmapNPCCount]= peopleList[i].innerText + ';' + targetCode  ;
                            gmapNPCPath[gmapNPCCount]= gstrNpcPath ;

                        }
                        gmapNPCCount = gmapNPCCount +1;
                    }
                }
            }
        }
    }

    var d = dir.split(";");
    if(d[steps]=='halt') {

        gstrNpcPath = gstrNpcPath + ';' + d[steps];
        steps += 1;
        return;
    }
    if(steps < d.length ){

        clickButton(d[steps]);

        if (gstrNpcPath == ''){
            gstrNpcPath = d[steps];
        }else{
            gstrNpcPath = gstrNpcPath + ';' + d[steps];
        }
        steps += 1;
        setTimeout(function(){GetNPCPath(dir);},300);
    }else{
        steps= 0 ;
        gstrNpcPath = 0 ;
        //   gmapNPCList.sort();
        var npcpathlog='NPC 数量：' + (gmapNPCList.length) + '\n' ;
        for ( i=0 ; i <  gmapNPCList.length ; i++){
            npcpathlog = npcpathlog + gmapNPCList[i] + "路径--" + gmapNPCPath[i] + '\n';
        }
        // console.log(npcpathlog);
        //  PuzzleNextFunc();
        NpcBatchAskStartFunc();

    }


}


///-------------------------分割线-----------
//接谜题单个或者多个

function PuzzleNextFunc(){

    if ( iBatchAskModel == 1){ //批量接谜题模式

        if (iPuzzleOrders == -1 ){ // 每个地图第一个NPC
            iPuzzleOrders = iPuzzleOrders + 1;
            if (  iPuzzleOrders  <  gmapNPCList.length )
            {
                btnList["进度"].innerText = '[' +( iPuzzleOrders + 1 )  +   ' -> ' + gmapNPCList.length + ']' + gmapNPCList[iPuzzleOrders].split(";")[0] ;
                go ( gmapNPCPath[iPuzzleOrders] );
                go ("ask "+gmapNPCList[iPuzzleOrders].split(";")[1]);

            }


        }else{

            iPuzzleOrders = iPuzzleOrders + 1;


            if (  iPuzzleOrders  <  gmapNPCList.length ){
                btnList["进度"].innerText = '[' +( iPuzzleOrders + 1 )  +   ' -> ' + gmapNPCList.length + ']' + gmapNPCList[iPuzzleOrders].split(";")[0] ;

                if (gmapNPCPath[iPuzzleOrders] == gmapNPCPath[iPuzzleOrders - 1]){


                    go ("ask "+gmapNPCList[iPuzzleOrders].split(";")[1]);



                }else{
                    //先走路然后接谜题
                    //       console.log("路径1："+ gmapNPCList[iPuzzleOrders - 1].split(";")[0] +"--" + gmapNPCPath[iPuzzleOrders - 1]);
                    //         console.log("路径2："+ gmapNPCList[iPuzzleOrders].split(";")[0] +"--" + gmapNPCPath[iPuzzleOrders ]);
                    //        console.log("路径2："+ gmapNPCPath[iPuzzleOrders].substr(gmapNPCPath[iPuzzleOrders - 1].length + 1));
                    go(gmapNPCPath[iPuzzleOrders].substr(gmapNPCPath[iPuzzleOrders - 1].length + 1));
                    go ("ask "+gmapNPCList[iPuzzleOrders].split(";")[1]);
                }
            }else{
                //批处理模式关闭  , 打开谜题自动模式 ,显示当前谜题

                iBatchAskStart =0;
                //    listenPuzzleFunc();// 自动处理任务模式
                eval("clickButton('task_quest')") ;//显示任务列表
                return;



            }
        }

    }else if(  iBatchAskModel ==0) {

        iPuzzleOrders = iPuzzleOrders + 1;
        if (  iPuzzleOrders  <  gmapNPCList.length )
        {
            btnList["进度"].innerText = '[' +( iPuzzleOrders + 1 )  +   ' -> ' + gmapNPCList.length + ']' + gmapNPCList[iPuzzleOrders].split(";")[0] ;
            go ( gmapNPCPath[iPuzzleOrders] );
            go ("ask "+gmapNPCList[iPuzzleOrders].split(";")[1]);

        }else
        {
            //    alert("当前地图迷题已经扫完");

        }
    }



}

///-------------------------分割线-----------
//产生地图NPC路径

function PuzzleNPCGoFunc(){
    var num  = 0;
    if(!( num  = prompt("请输入谜题NPC顺序：","1"))){
        return;
    }
    num  = parseInt(num);
    num = num -1;
    if (gmapNPCList.length<=0) {
        return;
    }
    if ( num < 0 && num >= gmapNPCList.length ){
        return;
    }


    iPuzzleOrders =num;
    if (  iPuzzleOrders  <  gmapNPCList.length )
    {
        btnList["进度"].innerText = '[' +( iPuzzleOrders + 1 )  +   ' -> ' + gmapNPCList.length + ']' + gmapNPCList[iPuzzleOrders].split(";")[0] ;
        go ( gmapNPCPath[iPuzzleOrders] );
        go ("ask "+gmapNPCList[iPuzzleOrders].split(";")[1]);

    }else
    {
        //    alert("当前地图迷题已经扫完");

    }



}

///-------------------------分割线-----------
//产生地图NPC路径



function PuzzleNPCAsk(){
    if (  iPuzzleOrders  <  gmapNPCList.length && iPuzzleOrders >= 0 )
    {
        go ("ask "+gmapNPCList[iPuzzleOrders].split(";")[1]);
    }

}

///-------------------------批量接谜题设置分割线-----------
//产生地图NPC路径
iBatchAskModel=0;
function NpcBatchAskFunc(){

    if (Puzzletrigger==1){
        listenPuzzleFunc();

    }




    if (iBatchAskModel == 0){
        iBatchAskModel=1;

        btnList["单谜题"].innerText = '多谜题';




    }else if (iBatchAskModel == 1){
        iBatchAskModel=0;
        iBatchAskStart =0;
        btnList["单谜题"].innerText = '单谜题';

    }

}
//批量接谜题开始
iBatchAskStart =0;
iValidPuzzleNum=1;

function NpcBatchAskStartFunc(){

    if (iBatchAskModel == 1){

        if (Puzzletrigger==1){
            listenPuzzleFunc();

        }
        iBatchAskStart = 1;

    }
    iPuzzleOrders = iPuzzleOrders + 1;
    if (  iPuzzleOrders  <  gmapNPCList.length )
    {
        btnList["进度"].innerText = '[' +( iPuzzleOrders + 1 )  +   ' -> ' + gmapNPCList.length + ']' + gmapNPCList[iPuzzleOrders].split(";")[0] ;
        go ( gmapNPCPath[iPuzzleOrders] );
        go ("ask "+gmapNPCList[iPuzzleOrders].split(";")[1]);

    }else
    {
        //    alert("当前地图迷题已经扫完");

    }

}

function GetNPCStartMap(w){

    //  go('home');
    clickButton('home');     //回主页
    //   WhoAmIFunc();

    if(btnList["自动战斗"].innerText  == '自动战斗'){
        AutoKillFunc();
    }

    gstrNpcPath='';
    gmapNPCList = [];
    gmapNPCPath = [];
    tempNPCList = [];
    gmapNPCCount=0;
    steps=0;
    iPuzzleOrders = -1 ;

    // go_path = "jh 1;e;s;w;w;e;s;n;e;e;ne;ne;sw;sw;n;w;n;e;e;n;s;e;e;n;s;e;w;s;n;w;w;w;w;w;e;n;w;e;n;w;e;e;e;w;w;n;n;s;e;w;w";
    //go_path = "jh 2;n;n;e;s;n;w;n;e;s;n;w;w;e;n;w;s;w;e;n;e;e;s;n;w;n;w;n;n;w;e;s;s;s;n;w;n;n;n;e;w;s;s;w;e;s;e;e;e;n;s;e;n;n;w;e;e;n;s;w;n;w;e;n;e;w;n;w;e;s;s;s;s;s;w;w;n;w;e;e;n;s;w;n;e;w;n;w;e;e;w;n;e;n;n";
    //   go_path = "jh 3;n;e;w;s;w;e;s;e;n;s;w;s;e;s;n;w;w;n;s;e;s;s;w;n;s;e;s;e;w;nw;n;n;e;w;n;w;e;n;n;w;e;e;w;n";
    if (w.startsWith("雪亭镇")) {
        go_path = "jh 1;e;s;w;w;e;s;n;e;e;ne;ne;sw;sw;n;w;n;e;e;n;s;e;e;n;s;e;w;s;n;w;w;w;w;w;e;n;w;e;n;w;e;e;e;w;w;n;n;s;e;w;w";
    } else if (w.startsWith("洛阳")) {
        go_path = "jh 2;n;n;e;s;n;w;n;e;s;n;w;w;e;n;w;s;w;e;n;e;e;s;n;w;n;w;n;n;w;e;s;s;s;n;w;n;n;n;e;w;s;s;w;e;s;e;e;e;n;s;e;n;n;w;e;e;n;s;w;n;w;e;n;e;w;n;w;e;s;s;s;s;s;w;w;n;w;e;e;n;s;w;n;e;w;n;w;e;e;w;n;e;n;n";
    } else if (w.startsWith("华山村")) {
        go_path = "jh 3;n;e;w;s;w;e;s;e;n;s;w;s;e;s;n;w;w;n;s;e;s;s;w;n;s;e;s;e;w;nw;n;n;e;w;n;w;e;n;n;w;e;e;w;n";
    } else if (w.startsWith("华山")) {
        go_path = "jh 4;n;n;w;e;n;e;w;n;n;n;e;n;n;s;s;w;n;n;w;s;n;w;n;s;e;e;n;e;n;n;w;e;n;e;w;n;e;w;n;s;s;s;s;s;w;n;w;e;n;n;w;e;e;s;s;n;n;n;n;s;s;w;n";
    } else if (w.startsWith("扬州")) {
        go_path = "jh 5;n;w;w;n;s;e;e;e;w;n;w;e;e;w;n;w;e;n;w;e;n;w;w;s;s;n;n;n;n;w;n;n;n;s;s;s;e;e;w;n;s;s;s;e;e;e;n;n;n;s;s;w;n;e;n;n;s;s;e;n;n;w;n;n;s;s;w;s;s;e;e;s;w;s;w;n;w;e;e;n;n;e;w;w;e;n;n;s;s;s;s;w;n;w;e;e;w;n;w;w;n;s;e;e;n;e;s;e;s;s;s;n;n;n;w;n;w;w;s;n;w;n;w;e;e;w;n;n;w;n;s;e;e;s;n;w;n";
    } else if (w.startsWith("丐帮")) {
        go_path = "jh 6;event_1_98623439;ne;n;ne;ne;ne;sw;sw;sw;s;ne;ne;sw;sw;sw;s;w";
    } else if (w.startsWith("乔阴县")) {
        go_path = "jh 7;s;s;s;w;s;w;w;w;e;e;e;e;s;s;e;n;n;e;w;s;s;w;s;w;w;w;n;s;s;e;n;s;e;ne;s;e;n;e;s;e";
    } else if (w.startsWith("峨眉山")) {
        go_path = "n;n;n;e;e;w;w;w;n;n;n;w;w;s;e;w;s;e;w;w;e;n;w;e;n;w;w;n;s;sw;ne;e;e;n;e;w;w;e;n;e;w;w;e;n;w;w;w;n;n;n;s;s;s;e;e;e;e;e;e;e;e;e;w;w;s;e;w;w;e;s;e;w;w;e;s;e;e;w;w;s;e;w;w;e;s;e;w;w;e;n;n;w;w;n;n;n;n;w;n;s;w;e;s;n;e;n;n;n;n;s;s;nw;nw;n;n;s;s;se;sw;w;nw;w;e;se;e;ne;se;ne;se;s;se;nw;n;nw;ne;n;s;se;e";
    } else if (w.startsWith("恒山")) {
        go_path = "jh 9;n;w;e;n;e;w;n;w;e;n;e;w;n;n;n;w;n;s;s;n;e;e;n;s;e;w;w;n;n;w;n;e;w;n;n;w;e;n";
    } else if (w.startsWith("武当山")) {
        go_path = "jh 10;w;n;n;w;w;w;n;n;n;n;n;w;n;s;e;n;n;n;n;s;s;s;s;e;e;s;n;e;e;w;w;w;w;s;e;e;e;e;s;e;s;e;n;s;s;n;e;e;n;s;e;w;s;s;s";
    } else if (w.startsWith("晚月庄")) {
        go_path = "jh 11;e;e;n;e;s;sw;se;s;s;s;s;s;s;se;s;n;ne;n;nw;w;w;s;s;w;e;se;e;n;n;n;n;n;n;w;n;s;w;n;w;e;s;w;w;e;s;n;e;s;w;e;s;e;e;e;w;w;w;w;w;n;s;s;n;e;s;n;e;s;w;w;e;e;e;s;s;e;w;w;s;e;e;w;w;n;e;w;w;w;e;n;n;n;s;w;e;s;e;s;n;n;e";
    } else if (w.startsWith("水烟阁")) {
        go_path = "jh 12;n;e;w;n;n;n;s;w;n;n;e;w;s;nw;e;n;s;e;sw;n;s;s;e";
    } else if (w.startsWith("少林寺")) {
        go_path = "jh 13;e;s;s;w;w;w;e;e;n;n;w;n;w;w;n;s;e;e;n;e;w;w;e;n;n;e;w;w;e;n;n;e;w;w;e;n;n;e;w;w;e;n;n;e;s;s;s;s;s;s;s;s;n;n;n;n;n;n;n;n;w;w;s;s;s;s;s;s;s;s;n;n;n;n;n;n;n;n;e;n;e;w;w;e;n;w;n";
    } else if (w.startsWith("唐门")) {
        go_path = "jh 14;e;w;w;n;n;n;n;s;w;n;s;s;n;w;n;s;s;n;w;n;s;s;n;w;e;e;e;e;e;s;n;e;n;e;w;n;n;s";
    } else if (w.startsWith("青城山")) {
        go_path = "jh 15;s;s;e;w;w;n;s;e;s;e;w;w;w;n;s;s;s;n;n;w;w;w;n;s;w;e;e;e;e;e;e;s;e;w;w;e;s;e;w;s;w;s;ne;s;s;s;e;s;n;w;n;n;n;n;n;n;n;n;n;n;nw;w;nw;n;s;w;s;s;s";
    } else if (w.startsWith("逍遥林")) {
        go_path = "jh 16;s;s;s;s;e;e;e;s;w;w;w;w;w;e;n;s;s;n;e;e;n;n;s;s;s;s;n;n;e;n;s;s;s;n;n;e;e;n;n;e";
    } else if (w.startsWith("开封")) {
        go_path = "jh 17;sw;s;sw;nw;ne;sw;se;ne;n;ne;n;w;e;e;s;n;w;n;w;n;n;s;s;e;e;e;n;n;s;s;s;n;w;s;s;s;w;e;e;n;s;e;e;w;w;s;n;w;s;w;e;n;n;n;n;w;n;e;w;n;w;e;e;w;n;e;n;n;n;s;s;s;w;s;s;s;s;s;e;s;s;s;e;w;s;s;w";
    } else if (w.startsWith("明教")  || w.startsWith("光明顶")) {
        go_path = "jh 18;e;w;w;n;s;e;n;nw;n;n;w;e;n;n;n;ne;n;n;w;e;e;w;n;w;e;e;w;n;n;w;w;s;n;n;e;e;e;e;s;se;se;e;w;nw;nw;w;w;n;w;w;n;n;e;nw;se;e;e;e;se;e;w;sw;s;w;w;n;e;w;n;e;w;w;e;n;n;n;n;w;e;n;event_1_90080676;event_1_56007071;ne;n";
    } else if (w.startsWith("全真教")) {
        go_path = "jh 19;s;s;s;sw;s;e;n;nw;n;n;n;n;e;w;w;e;n;e;n;s;e;e;w;n;n;s;s;w;w;w;w;w;w;s;n;e;s;n;e;e;e;n;n;w;w;s;s;n;n;w;s;s;n;n;w;n;n;n;n;n;n;e;n;e;e;n;n;s;s;e;e;e;e;s;e;s;s;s;n;w;n;s;s;s;s;w;s;n;w;n;e;n;n;n;s;w;n;n;n;s;s;s;w;n;s;w;n;s;s;s;e;n;n;e;s;s;s;w";
    } else if (w.startsWith("古墓")) {
        go_path = "jh 20;s;s;n;n;w;w;s;e;s;s;s;s;s;sw;sw;s;e;se;nw;w;s;w;e;e;w;s;s;w;w;e;s;sw;ne;e;s;s;w;w;e;e;s;n;e;e;e;e;s;e;w;n;w;n;n;s;e;w;w;s;n;n;n;n;s;e;w;w";
    } else if (w.startsWith("白驮山")) {
        go_path = "jh 21;nw;s;n;ne;ne;sw;n;n;ne;w;e;n;n;w;w;e;e;s;s;sw;s;s;sw;w;n;s;w;nw;e;w;nw;nw;n;w;sw;ne;e;s;se;se;n;e;w;n;n;w;e;n;n;w;w;w;n;n;n;n;s;s;s;e;e;e;n;s;s;n;e;e;e;w;ne;sw;n;n;w;e;e;e;w;w;n;nw;se;ne;w;e;e;w;n";
    }  else if (w.startsWith("嵩山")) {
        go_path = "jh 22;n;n;w;w;s;s;s;s;s;n;w;e;n;n;e;w;n;n;e;n;n;n;n;n;e;n;e;w;n;w;n;s;e;n;n;n;w;w;e;n;w;e;n;s;s;e;e;w;n;e;w;n;e;w;n";
    } else if (w.startsWith("寒梅庄")) {
        go_path = "jh 23;n;n;e;w;n;n;n;n;n;w;w;e;e;e;s;n;w;n;w;w;e;n;s;e;e;n;s;w;n;n;e;w;w;n";
    } else if (w.startsWith("泰山")) {
        go_path = "jh 24;n;n;n;n;e;e;w;s;n;w;w;e;n;n;w;e;e;w;n;e;w;n;w;n;n;n;n;n;s;s;w;n;s;e;s;s;s;e;n;e;w;n;w;e;n;n;w;n;n;n;n;e;w;s;s;w;e;s;e;w;s;e;e;s;n;e;n;e;w;n;w;e;e;w;n;n;s;s;s;s;s;w;w;n;n;e;w;w;e;n;n;e;w;w;e;n";
    } else if (w.startsWith("大旗门")) {
        go_path = "jh 25;w;e;e;e;e;e;s";
    } else if (w.startsWith("大昭寺")) {
        go_path = "jh 26;w;w;n;n;s;w;e;e;e;e;w;w;w;s;w;w;w;n;s;w;n;n;e;w;w;w;w;w;s;s;s;s;s;e;s;e;e;e;n;w;e;e;e;w;w;n;w;w;n;e;w;w;e;s;w;n;s;s;n;w";
    } else if (w.startsWith("魔教")) {
        go_path = "jh 27";
    }else{
        w = null;
        return ;
    }




    gstrMapPath=go_path;
    btnList["迷题扫图"].innerText = w;
    setTimeout(function(){GetNPCPath(go_path) ;},500);


}

function GoStartXTZ(){
    GetNPCStartMap("雪亭镇");
}


function GoStartLY(){
    GetNPCStartMap("洛阳");
}

function GoStartHSC(){
    GetNPCStartMap("华山村");
}

function GoStartHS(){
    GetNPCStartMap("华山");
}

function GoStartYZ(){
    GetNPCStartMap("扬州");
}

function GoStartGB(){
    GetNPCStartMap("丐帮");
}

function GoStartQYX(){
    GetNPCStartMap("乔阴县");
}

function GoStartHS1(){
    GetNPCStartMap("恒山");
}
function GoStartWDS(){
    GetNPCStartMap("武当山");
}
function GoStartWYZ(){
    GetNPCStartMap("晚月庄");
}
function GoStartSYG(){
    GetNPCStartMap("水烟阁");
}
function GoStartSLS(){
    GetNPCStartMap("少林寺");
}
function GoStartTM(){
    GetNPCStartMap("唐门");
}
function GoStartQCS(){
    GetNPCStartMap("青城山");
}
function GoStartXYL(){
    GetNPCStartMap("逍遥林");
}
function GoStartKF(){
    GetNPCStartMap("开封");
}
function GoStartMJ(){
    GetNPCStartMap("明教");
}

function GoStartQZJ(){
    GetNPCStartMap("全真教");
}

function GoStartGM(){
    GetNPCStartMap("古墓");
}

function GoStartBTS(){
    GetNPCStartMap("白驮山");
}

function GoStartSS(){
    GetNPCStartMap("嵩山");
}
function GoStartHMZ(){
    GetNPCStartMap("寒梅庄");
}
function GoStartTS(){
    GetNPCStartMap("泰山");
}
function GoStartDQM(){
    GetNPCStartMap("大旗门");
}
function GoStartDZS(){
    GetNPCStartMap("大昭寺");
}

// ==/UserScript==------------------------------------------------------------------------------------------------------------
// 扩展功能----------------------------------------------------------------------------------------------------------
var btnList3 = {};       // 按钮列表
var buttonWidth = '70px';   // 按钮宽度
var buttonHeight = '20px';  // 按钮高度
var currentPos = 10;        // 当前按钮距离顶端高度，初始130
var delta = 25;                 // 每个按钮间隔

//按钮加入窗体中----------------------------
function isContains(str, substr) {
    return str.indexOf(substr) >= 0;
}
function createButton3(btnName,func){
    btnList3[btnName]=document.createElement('button');
    var myBtn = btnList3[btnName];
    myBtn.innerText = btnName;
    myBtn.style.color =color;
    myBtn.style.background = ground;
    myBtn.style.position = 'absolute';
    myBtn.style.right = '120px';
    myBtn.style.top = currentPos + 'px';
    currentPos = currentPos + delta;
    myBtn.style.width = buttonWidth;
    myBtn.style.height = buttonHeight;
    myBtn.addEventListener('click', func);
    document.body.appendChild(myBtn);
}

//按钮列表----------------------------------
var color='#E0FFFF';var ground='#FF7F50';
createButton3('雪亭镇',GoStartXTZ);
createButton3('洛阳',GoStartLY);
createButton3('华山村',GoStartHSC);
createButton3('华山',GoStartHS);
createButton3('扬州',GoStartYZ);
createButton3('丐帮',GoStartGB);
createButton3('乔阴县',GoStartQYX);
createButton3('恒山',GoStartHS1);
createButton3('武当山',GoStartWDS);
createButton3('晚月庄',GoStartWYZ);
createButton3('水烟阁',GoStartSYG);
createButton3('少林寺',GoStartSLS);
createButton3('唐门',GoStartTM);
createButton3('青城山',GoStartQCS);
createButton3('逍遥林',GoStartXYL);
createButton3('开封',GoStartKF);
createButton3('明教',GoStartMJ);
createButton3('全真教',GoStartQZJ);
createButton3('古墓',GoStartGM);
createButton3('白驼山',GoStartBTS);
createButton3('嵩山',GoStartSS);
createButton3('寒梅庄',GoStartHMZ);
createButton3('泰山',GoStartTS);
createButton3('大旗门',GoStartDQM);
createButton3('大昭寺',GoStartDZS);

//隐藏所有按钮的按钮----------------------------------
var buttonhiden=0;
function buttonhide3Func(){
    if (buttonhiden==0){
        buttonhiden=1;
        btnList['选择地图'].innerText = '选择地图';
        hideButton3();
    }else{
        buttonhiden=0;
        btnList['选择地图'].innerText = '隐藏地图';
        showButton3();
    }
}
function hideButton3(){
btnList3['雪亭镇'].style.visibility="hidden";
btnList3['洛阳'].style.visibility="hidden";
btnList3['华山村'].style.visibility="hidden";
btnList3['华山'].style.visibility="hidden";
btnList3['扬州'].style.visibility="hidden";
btnList3['丐帮'].style.visibility="hidden";
btnList3['乔阴县'].style.visibility="hidden";
btnList3['恒山'].style.visibility="hidden";
btnList3['武当山'].style.visibility="hidden";
btnList3['晚月庄'].style.visibility="hidden";
btnList3['水烟阁'].style.visibility="hidden";
btnList3['少林寺'].style.visibility="hidden";
btnList3['唐门'].style.visibility="hidden";
btnList3['青城山'].style.visibility="hidden";
btnList3['逍遥林'].style.visibility="hidden";
btnList3['开封'].style.visibility="hidden";
btnList3['明教'].style.visibility="hidden";
btnList3['全真教'].style.visibility="hidden";
btnList3['古墓'].style.visibility="hidden";
btnList3['白驼山'].style.visibility="hidden";
btnList3['嵩山'].style.visibility="hidden";
btnList3['寒梅庄'].style.visibility="hidden";
btnList3['泰山'].style.visibility="hidden";
btnList3['大旗门'].style.visibility="hidden";
btnList3['大昭寺'].style.visibility="hidden";

}
function showButton3(){
btnList3['雪亭镇'].style.visibility="visible";
btnList3['洛阳'].style.visibility="visible";
btnList3['华山村'].style.visibility="visible";
btnList3['华山'].style.visibility="visible";
btnList3['扬州'].style.visibility="visible";
btnList3['丐帮'].style.visibility="visible";
btnList3['乔阴县'].style.visibility="visible";
btnList3['恒山'].style.visibility="visible";
btnList3['武当山'].style.visibility="visible";
btnList3['晚月庄'].style.visibility="visible";
btnList3['水烟阁'].style.visibility="visible";
btnList3['少林寺'].style.visibility="visible";
btnList3['唐门'].style.visibility="visible";
btnList3['青城山'].style.visibility="visible";
btnList3['逍遥林'].style.visibility="visible";
btnList3['开封'].style.visibility="visible";
btnList3['明教'].style.visibility="visible";
btnList3['全真教'].style.visibility="visible";
btnList3['古墓'].style.visibility="visible";
btnList3['白驼山'].style.visibility="visible";
btnList3['嵩山'].style.visibility="visible";
btnList3['寒梅庄'].style.visibility="visible";
btnList3['泰山'].style.visibility="visible";
btnList3['大旗门'].style.visibility="visible";
btnList3['大昭寺'].style.visibility="visible";
}
btnList3['雪亭镇'].style.right = '210px';btnList3['雪亭镇'].style.top = '10px';
btnList3['洛阳'].style.right = '210px';btnList3['洛阳'].style.top = '35px';
btnList3['华山村'].style.right = '210px';btnList3['华山村'].style.top = '60px';
btnList3['华山'].style.right = '210px';btnList3['华山'].style.top = '85px';
btnList3['扬州'].style.right = '210px';btnList3['扬州'].style.top = '110px';
btnList3['丐帮'].style.right = '210px';btnList3['丐帮'].style.top = '135px';
btnList3['乔阴县'].style.right = '210px';btnList3['乔阴县'].style.top = '160px';
btnList3['恒山'].style.right = '210px';btnList3['恒山'].style.top = '185px';
btnList3['武当山'].style.right = '210px';btnList3['武当山'].style.top = '210px';
btnList3['晚月庄'].style.right = '210px';btnList3['晚月庄'].style.top = '235px';
btnList3['水烟阁'].style.right = '210px';btnList3['水烟阁'].style.top = '260px';
btnList3['少林寺'].style.right = '210px';btnList3['少林寺'].style.top = '285px';
btnList3['唐门'].style.right = '210px';btnList3['唐门'].style.top = '310px';
btnList3['青城山'].style.top = '10px';
btnList3['逍遥林'].style.top = '35px';
btnList3['开封'].style.top = '60px';
btnList3['明教'].style.top = '85px';
btnList3['全真教'].style.top = '110px';
btnList3['古墓'].style.top = '135px';
btnList3['白驼山'].style.top = '160px';
btnList3['嵩山'].style.top = '185px';
btnList3['寒梅庄'].style.top = '210px';
btnList3['泰山'].style.top = '235px';
btnList3['大旗门'].style.top = '260px';
btnList3['大昭寺'].style.top = '285px';

buttonhide3Func();